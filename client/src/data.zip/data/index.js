export const cardSlidesImagesData = [
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/74063d59d1921b3412635ecaac0e7919",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/7ebf45031bda9543a8da829d532d796c",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/4f8762ce64cbbaface30371b88ba58d1",
  },
];
export const submenuItems = [
  { title: "New For 2024!", url: "/category/news-2024" },
  { title: "Indoor Soft Play Packages", url: "/category/indoor-soft-play" },
  { title: "Christmas Inflatables", url: "/category/chrismis-inflatables" },
  { title: "Bouncy Castles", url: "/category/bouncy-castles" },
  { title: "Disco Domes", url: "/category/disco-domes" },
  { title: "Assault Course", url: "/category/asult-course" },
  { title: "Bounce & Slide Combos", url: "/category/bounce-slide-combos" },
  { title: "ADULT CASTLES", url: "/category/adult-castles" },
  { title: "Soft Play", url: "/category/soft-play" },
  { title: "Party Add-ons", url: "/category/party-add-ons" },
  { title: "Music Amps", url: "/category/music-amps" },
  { title: "Inflatable Games", url: "/category/inflatable-games" },
  {
    title: "Generator Hire Section",
    url: "/category/generator-hier-section",
  },
  { title: "Party Entertainer", url: "/category/party-entertainer" },
];
export const ribbons = [
  {
    img: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/category-blue.png",
    title: "Fun Fairs",
    url: "/category/news-2024",
  },
  {
    img: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/category-green.png",
    title: "Birthday Parties",
    url: "/category/indoor-soft-play",
  },
  {
    img: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/category-orange.png",
    title: "Indoor Bouncy Castles Event Packages",
    url: "/category/chrismis-inflatables",
  },
  {
    img: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/category-pink.png",
    title: "Bouncy castels",
    url: "/category/bouncy-castles",
  },
  {
    img: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/category-blue.png",
    title: "Go Karting",
    url: "/category/disco-domes",
  },
  {
    img: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/category-green.png",
    title: "Zorb balls",
    url: "/category/asult-course",
  },
  {
    img: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/category-orange.png",
    title: "Football Penalty Shoutout",
    url: "/category/bounce-slide-combos",
  },
  {
    img: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/category-pink.png",
    title: "Obstode Assault Course",
    url: "/category/adult-castles",
  },
  {
    img: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/category-blue.png",
    title: "Other inflatables",
    url: "/category/soft-play",
  },
  {
    img: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/category-green.png",
    title: "Disco Dome",
    url: "/category/party-add-ons",
  },

  {
    img: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/category-pink.png",
    title: "Inflatable Slides",
    url: "/category/inflatable-games",
  },
  {
    img: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/category-blue.png",
    title: "Generator Hire Section",
    url: "/category/generator-hier-section",
  },
  {
    img: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/category-green.png",
    title: "Obstacle Assult Course",
    url: "/category/party-entertainer",
  },
  {
    img: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/category-orange.png",
    title: "All Products",
    url: "/all-products",
  },
];
export let cardData = [
  {
    price: "900£",
    bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-orange.png",
    title: "Go kart",
    img: "/images/img2.jpg",
    size:['4 karts-inflatable track size<','16m (L) x 12m (W) = 192m²','Required space: 17m X 13m'],
    description: "Experience the ultimate adventure with our new Go kart bouncy castle! This 4-kart inflatable track size will be perfect for your adventurous adventures. Our Go kart bouncy castle features a 16m (L) x 12m (W) surface area and a required space of 17m x 13m. The castle boasts a comfortable, yet secure",
    suitability:['Suitable for all ages','Perfect for various events','Indoor on hard surface - Yes','Outdoor on grass - Yes','Outdoor on hard surface - Yes']
  },
  {
    price: "900£",
    bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-green.png",
    title: "Zorb balls",
    img: "/images/zorbBalls.jpg",
    size:['4 Zorb balls-inflatable track size-25m(L) X 25m(W) =192m²'],
    description: "Let's dive into the thrill of the unknown! The Zorb Ball is perfect for those craving excitement. It's a safe and exhilarating experience where you roll downhill inside a transparent plastic orb. The Zorb consists of two balls with an air layer in between, making the ride both fun and secure. In essence, Zorb experiences are all about enjoyment with a touch of adventure, rather than fear.",
    suitability:['Age-5 & adults','Suitable for all ages','Perfect for various events','Indoor on hard surface - Yes','Outdoor on grass - Yes','Outdoor on hard surface - no']
  },
  {
    price: "950£",
    bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-pink.png",
    title: "Mega Wave Bouncy Slide",
    img: "/images/megaWave.png",
    size:['1m(L) x 7m(W) x 6(H) Required space – 10m x 7m'],
    description: "This 25ft Wave slide is designed for the over 5's and also for adultsThe wave slide is an added dimension to the standard slide, and side by side a standard slide, this one is more attractive giving the think of the wave. Kids absolutelylove the wave slide which is seen when you see them racing to climb itagain.",
    suitability:['Age-5 & adults','Suitable for all ages','Indoor on hard surface – yes, if ceiling is high enough','Indoor on hard surface - Yes','Outdoor on grass - Yes','Outdoor on hard surface - yes']
  },
  {
    price: "800£",
    bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-blue.png",
    title: "Rainbow Giant Slide ",
    img: "/images/rainbowGiant.jpg",
    size:['Item size: 9m (L) x 7m(W),','Required space:10mx8m'],
    description: "Rainbow Slide is a fantastic addition to any birthday party or event, guaranteed to keep children entertained with its exhilarating drop. Its vibrant, multicolored design adds a touch of excitement. With its thrilling ride and eye-catching appearance, the Rainbow slide is sure to be a hit at any celebration.",
    suitability:['Age-3 & adults','Suitable for all ages','Indoor on hard surface – yes, if ceiling is high enough','Indoor on hard surface - Yes','Outdoor on grass - Yes','Outdoor on hard surface - yes']
  },
  {
    price: "700£",
    bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-pink.png",
    title: "Toddler Slide",
    img: "/images/toddlerSlide.jpg",
    size:['Item size: 8m (L) x 5m(W),','Required space:9mx6m'],
    description: "Designed for the under 6's. This attraction is a bouncy castle and 10ft slide attached. The unders 6's find theslide easy to climb and whizz down to the bouncy area that is surrounded by images of Disney characters.",
    suitability:['Age-under 6','Suitable for all ages','Indoor on hard surface – yes, if ceiling is high enough','Indoor on hard surface - Yes','Outdoor on grass - Yes','Outdoor on hard surface - yes']
  },
  {
    price: "300£",
    bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-pink.png",
    title: "Bouncy Castle with slide Combi - Pink & Purple",
    img: "/images/shootOut.jpg",
    size:['Item size: 5m (L) x 5m(W) =25m²,','Required space:6mx6m'],
    description: "Introducing our Bouncy Castle – the ultimate attraction for kids under 6! This delightful bouncy castle is perfect for adding a splash of fun and excitement to any birthday party or event. With its vibrant colors and playful design, it’s sure to captivate young imaginations and keep little ones entertained for hours. Ideal for creating unforgettable memories, this bouncy castle combines safety with joy, making it a fantastic choice for any celebration.",
    suitability:['Age-under 6','Suitable for all ages','Indoor on hard surface – yes, if ceiling is high enough','Indoor on hard surface - Yes','Outdoor on grass - Yes','Outdoor on hard surface - yes']
  },
  {
    price: "200£",
    bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-blue.png",
    title: "Penalty SHoot Out",
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_300/c8f3b441a4c1a216c1932e6bf32b3865",
    size:['Item size: 5m (L) x 3m(W) =25m²,'],
    description: "Try your hand at scoring a goal with this exciting attraction that appeals to all ages! Kids are drawn in by the fun cartoon characters, while adults are eager to show off their skills. This engaging challenge is perfect for testing your accuracy and coordination. It's a fantastic way to get into the spirit of the World Cup and adds a lively, competitive edge to any event. Get ready to kick, score, and enjoy the fun!",
    suitability:['Age-3+ and Adult','Suitable for all ages','Indoor on hard surface – yes, if ceiling is high enough','Indoor on hard surface - Yes','Outdoor on grass - Yes','Outdoor on hard surface - yes']
  },
  {
    price: "400£",
    bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-orange.png",
    title: "Chocolate Fountain",
    img: "/images/fountain.jpg",
    size:['Item size: 5m (L) x 3m(W) =25m²,'],
    description: "Indulge in a luxurious treat with our Chocolate Fountain, featuring five cascading levels and a large capacity that holds up to 6 kg of your favorite ingredients. This delightful centerpiece is perfect for any event or celebration, creating a continuous flow of rich, melted chocolate that invites guests to dip fruits, marshmallows, and other treats. With its sleek stainless steel design and user-friendly operation, the Chocolate Fountain adds a touch of decadence and interactive fun to your gathering, ensuring a memorable experience for everyone. Our service provides Choice of 10 Dips, Unlimited Belgian Chocolate for up to 200 people (more available on request)",
    suitability:['Age-3+ and Adult','Suitable for all ages','Indoor on hard surface – yes, if ceiling is high enough','Indoor on hard surface - Yes','Outdoor on grass - Yes','Outdoor on hard surface - yes']
  },
 
  


,
  


  { price: 154.99 + 125, bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-pink.png", title: "Unicorn Bouncy Castle - Pink & Purple", img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_300/068d9d8e50b27d16579c9f8301ada306", description: "100% Five-Star Reviews Delivering All Promises\nAt Premium Inflatables, our commitment to excellence is reflected in our 100% five-star rating on Google. With hundreds of reviews from satisfied customers, we take pride in consistently delivering premium products and service. This unparalleled reputation sets us apart from the rest of the events and entertainment competition. Please be assured that your event is in the hands of trusted RPii-trained professionals.\n\nPremium Inflatables Guarantees\n- New fully sanitized 2024 Premium Inflatables & accessories\n- Delivering on time every time!\n- Punctual collections\n- Friendly, polite team dedicated to making your event safe and successful every time!\n- Around-the-clock customer service team\n\nWe understand that event planning can be stressful. Rest assured, once you’ve booked with us, you’ll have one less thing to worry about when it comes to your bouncy castles, slides, and inflatable games.\n\nOur under-5s Unicorn Themed Bouncy Castle is perfect for birthdays or special events. It boasts a modern gloss finish with classic cartoon artwork. This inflatable can be paired with slides, ball pools, and soft play for a premium deluxe package. Ideal for indoor or outdoor occasions.\n\nLooking for another theme? Check out our themed options for this same-sized castle:\n- Girly Pink Bouncy Castle\n- Mermaids Bouncy Castle\n- Princess Bouncy Castle\n- Butterflies Bouncy Castle\n\nSafety and hygiene are our top priorities! All our inflatables are fully sanitized, and we provide PAT testing where required, along with risk assessments and method statements. Our team is RPii trained and compliant with EN14960 & HSE guidelines.\n\nPremium Inflatables now available to hire across Leeds, Wakefield, and many surrounding areas.",

    suitability:['Suitable For Children','Not Suitable For Adults','Indoors on Hard Surface','Outdoors on Grass','Outdoors on Hard Surface','Not Suitable Outdoors on Artificial Grass','Not Suitable Outdoors on Flags'],
    size:['9ft,11.5ft,8ft','12ft,17ft,8.5ft','3ft'],
   },
   { price: 175.99 + 125, bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-pink.png", title: "Adults Happy Birthday Themed Bouncy Castle - Green & Light Blue", img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_300/9eec50bece18a4474b7a6a8a2cb47e20", description: "One of our new purchases and additions to our outstanding premium 2024 fleet!\n\nThe Happy Birthday Themed bouncy castle is an amazing addition to any birthday party or event. It features classic cartoon happy birthday artwork finished in a modern gloss, matching the premium gloss finish on all our inflatables.\n\nFor an even more exciting experience, you can upgrade your event with disco lights and a big Bluetooth speaker, taking the fun to the next level!\n\nThis bouncy castle is ideal for all your indoor and outdoor events and special occasions. Pair it with slides, ball pools, soft play, and matching mats for an incredible package.\n\nOur trained team will deliver and set up the inflatable at your home or chosen venue.\n\nPremium Inflatables are now available to hire across Leeds, Wakefield, Tingley, Morley, Lofthouse, Rothwell, Methley, Normanton, Featherstone, Pontefract, Castleford, Knottingley, Darrington, Wentbridge, Sherburn in Elmet, Selby, and surrounding areas." ,
    suitability:['Indoors on Hard Surface','Outdoors on Artificial Grass','Indoors on Hard Surface','Outdoors on Grass','Outdoors on Hard Surface','Not Suitable Outdoors on Artificial Grass','Not Suitable Outdoors on Flags'],
    size:['15ft,12ft,9.5ft','21ft,15ft,10ft'],

   },
  {
    price: 125.99 +125,
    bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-pink.png",
    title: "Basketball Shootout Game",
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_300/642475086aa267a93cd646ee33ac2910",
  },
  {
    price: 175.99 +125,
    bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-pink.png",
    title: "30ft Obstacle Assault Course Blue Fun Run",
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_300/bcf5b03a4052eadc358718a8e83f2702",
    description: `If you're looking for an exciting inflatable for your Wakefield party, then you've come to the right place. Our inflatable assault course fun run is perfect for any occasion, whether it's a birthday party, corporate team-building event, or just a day of fun with friends. At 30ft in length, this one-part assault course is designed to challenge everyone with a range of obstacles and a slide to finish.
  
  Our assault course is made by British manufacturers and is regularly inspected using the PIPA/RPII scheme to ensure it is safe for our customers to use. As members of the BIHA, you know you're in good hands for your assault course hire in Leeds.
  
  Why Choose Premium Inflatables Assault Course Hire Wakefield?
  - CLICK HERE TO SEE OUR GOOGLE CLIENT REVIEWS FEEDBACK
  
  Have our trained team deliver and set up this inflatable at your chosen home or venue. Now available to hire across Leeds, Wakefield, Tingley, Morley, Lofthouse, Rothwell, Methley, Normanton, Featherstone, Pontefract, Castleford, Knottingley, Darrington, Wentbridge, Sherburn in Elmet, Selby & surroundings.
  
  Contact Premium Inflatables:
  It couldn't be easier to get in touch with the team here at Premium Inflatables. You can reach us by using the contact form or:
  
  - Call our office on: 0113 460 1386
  - Mobile / WhatsApp / Text: 07482 511995
  - Email: info@premiuminflatables.co.uk
  
  Our office is open 7 days a week from 6am to 10pm. You are always welcome to leave us a message 24 hours a day.`,
  suitability:['Suitable For Children','Suitable For Adults','Indoors on Hard Surface','Outdoors on Grass','Outdoors on Hard Surface'],
  size:['10ft,30ft,11ft','6ft','4ft	'],
  }
,  
{
  price: 180.99 +125,
  bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-pink.png",
  title: "Adults Superheroes Themed Bouncy Castle - Green & Light Blue",
  img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_300/ea471e81e90b8bfe25934af7b2757c9a",
  description: `100% Five-Star Reviews Delivering All Promises
At Premium Inflatables, our commitment to excellence is reflected in our 100% five-star rating on Google. With hundreds of reviews from satisfied customers, we take pride in consistently delivering premium products and service. This unparalleled reputation sets us apart from the rest of the events and entertainment competition. Please be assured that your event is in the hands of trusted RPii-trained professionals.

Premium Guarantees:
- New fully sanitised 2024 Premium Inflatables & accessories
- Delivering on time every time!!
- Punctual collections
- Approachable, friendly, polite team dedicated to making your event safe and successful every time!!
- Around-the-clock customer service team to answer all your calls and messages

It is our duty to help create **The Best!!** Premium Events & Entertainment of 2024.

We understand as event organisers it can be a stressful time. Please be assured, with regards to your Premium Bouncy Castles, Slides, Assault Courses & Inflatable Games, we guarantee it will be one less thing to worry about once you have booked with us.

**Never to be mistaken** with lesser services offering low-quality, older, cheap bouncy castles for hire!!

**All our Hire Inflatables + Equipment** is certified to EN14960 & HSE guidelines as standard:
- Fully compliant with the European standard EN14960
- Each item has a current annual safety inspection certificate
- Design review pack included
- Risk assessment and method statement provided
- PAT tested where required
- £5,000,000 public liability insurance policy

All our Events Operators are fully PIPA trained & qualified to HSE-approved standards, with additional RPii qualifications for delivering and setting up our premium inflatables at your chosen grounds or venue.

The **Superheroes Themed Bouncy Castle** is an amazing addition to any birthday party or event, boasting classic cartoon superhero artwork finished in a modern gloss to match the premium finish on all our inflatables.

Take your special event to the next level by adding the ultimate bouncy castle upgrade, which includes disco lights and a big Bluetooth speaker!

This bouncy castle is ideal for all indoor and outdoor events and special occasions. It can easily be paired with slides, ball pools, soft play, and matching mat setups to make an incredible package.

Have our trained team deliver and set up this inflatable at your home or chosen venue.

Premium Inflatables are now available to hire across Leeds, Wakefield, Tingley, Morley, Lofthouse, Rothwell, Methley, Normanton, Featherstone, Pontefract, Castleford, Knottingley, Darrington, Wentbridge, Sherburn in Elmet, Selby & surroundings.`,
suitability:['Indoors on Hard Surface','Outdoors on Artificial Grass','Outdoors on Flags','Outdoors on Grass','Outdoors on Hard Surface'],
size:['15ft,12ft,9.5ft','21ft,15ft,10ft'],
}
,
{
  price: 145.99 +125,
  bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-pink.png",
  title: "Circus Bouncy Castle with Slide - Red & Blue",
  img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_300/73d628ebd4e07edf50fe730829fbdd15",
  description: `Welcome to Premium Inflatables - Your Number #1 Choice for bouncy castle hire in Leeds, Wakefield, and the surrounding areas.

Delivering you a choice of the UK's latest, most on-trend children's bouncy castles and **Promotional Price Premium Packages**.

Our printed **Circus Themed Bouncy Castle** is an amazing addition to any birthday party or event, boasting classic circus artwork, finished in a modern gloss to match the premium gloss finish on all our New 2024 inflatables.

**Premium Inflatables** brings you the latest and most on-trend purchases, with additions to our outstanding Premium 2024 Fleet! There's something for everyone!!

With years of expertise in the children's birthday party and entertainment industry, we understand the diverse needs at parties. That's why we're excited to offer **optional upgrades**, including:

- Circus Bouncy Castle & Matching Inflatable Ball Pool
- Circus Soft Play Bouncy Castle Package - Red / Blue

If this amazing inflatable wasn't enough, why not take your birthday party to the next level with our **Premium Entertainment Experience**? Upgrade to include disco lights and a big Bluetooth speaker!

The **Circus Themed Bouncy Castle** is ideal for all your indoor and outdoor events and special occasions. This castle can be easily paired with slides, matching ball pools, soft play, and matching mat setups to make an incredible package.

**Unrivaled Customer Satisfaction - 100% Five-Star Reviews**:
Our dedication to excellence is reflected in our reviews. With a 100% five-star rating, we are the number #1-rated **Bungee Run Hire** company on Google. Customer satisfaction drives our success.

Never settle for lesser services offering low-quality, older, cheap bouncy castles for hire!

**Safety and Hygiene are Paramount** at Premium Inflatables:
- All our premium inflatables, Circus Bouncy Castles, Soft Play, Ball Pools, Balls, and Mats come fully sanitised for every use.

Why Choose **Premium Inflatables Circus Bouncy Castle Hire Wakefield**?
- Have our RPii-trained team deliver and set up this inflatable at your home or venue.

Now available to hire across Leeds, Wakefield, Tingley, Morley, Lofthouse, Rothwell, Methley, Normanton, Featherstone, Pontefract, Castleford, Knottingley, Darrington, Wentbridge, Sherburn in Elmet, Selby, and surrounding areas.`,
suitability:['Suitable For Children','Not Suitable For Adults','Indoors on Hard Surface','Outdoors on Grass','Outdoors on Hard Surface'],
size:['12ft,15ft,9.5ft','15ft,21ft,10ft','3ft'],
}
,
 
{
  price: 45.99 +125,
  bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-pink.png",
  title: "Safety Supervisors Staffing",
  img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_300/94a5161af6006339a3553b1a0b468507",
  description: `**Safety Supervision** - 1x Supervisor per inflatable

**£45 per hour**

Please specify how many hours are required.

Now available to hire across Leeds, Wakefield, Tingley, Morley, Lofthouse, Rothwell, Methley, Normanton, Featherstone, Pontefract, Castleford, Knottingley, Darrington, Wentbridge, Sherburn in Elmet, Selby, and surrounding areas.`,
suitability:['Indoors on Hard Surface','Outdoors on Artificial Grass','Outdoors on Flags','Outdoors on Grass','Outdoors on Hard Surface'],

}
,
{
  price: 135.99 +125,
  bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-pink.png",
  title: "Party Time Pink Bouncy Castle Hire - Pink & Purple",
  img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_300/7436ded1e3d82f763837834baf099d51",
  description: `
**Premium Inflatables** - your local bouncy castle hire service, rated Number #1 on Google for Leeds, Wakefield, and surrounding areas.

Delivering you the latest, on-trend, high-quality additions to our outstanding Premium 2024 Fleet!

**Never to be mistaken for lesser services** offering low-quality or older, cheaper bouncy castles for hire.

The Party Time-themed bouncy castle is an amazing addition to any birthday party or event, boasting classic cartoon party time artwork and a modern gloss finish that matches all our inflatables.

Why not take your event to the next level with our **Premium Entertainment Experience**? Upgrade to include disco lights and a big Bluetooth speaker!

This bouncy castle is perfect for both indoor and outdoor events. It can also be paired with slides, ball pools, soft play, and matching mats for an incredible package.

**Safety and Hygiene** are our top priorities! All our inflatables, soft play items, ball pools, and mats are fully sanitized after every use.

Why Choose Premium Inflatables Bouncy Castle Hire Wakefield?

**Click here to see our Google client reviews!**

Our **RPii trained team** will deliver and set up this inflatable at your home or chosen venue.

Now available to hire across Leeds, Wakefield, Tingley, Morley, Lofthouse, Rothwell, Methley, Normanton, Featherstone, Pontefract, Castleford, Knottingley, Darrington, Wentbridge, Sherburn in Elmet, Selby, and surrounding areas.`,
suitability:['Suitable For Children','Not Suitable For Adults','Indoors on Hard Surface','Outdoors on Grass','Outdoors on Hard Surface'],
size:['15ft,12ft,9.5ft','21ft,15ft,10ft'],
}
,
  

{
  price: 35.99 +125,
  bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-pink.png",
  title: "Giant Connect 4 Game",
  img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_300/07bf24c3a21f3c6e8737f4b6f074d34c",
  description: `
**Introducing our New Giant Connect 4 Game!** This is a 3-in-1 design of the classic 4-in-a-row game, now on a bigger scale for even more fun! It's the perfect addition for both indoor and outdoor events, suitable for adults and children alike.

**Game Objective:** 
The aim is to block your opponent's pieces while trying to connect four of your own in a row or column.

**Dimensions:**
- Height: 79 cm
- Width: 33 cm
- Depth: 84 cm

This super fun game can easily be paired with our Didi Cars & Hoppers Package for amazing entertainment at your child's birthday party celebrations.
cardData
**Safety and Hygiene** are our top priorities! All our premium inflatables, soft play items, ball pools, and mats are fully sanitized after every use.

**Why Choose Premium Inflatables?** 
CLICK HERE TO SEE OUR GOOGLE CLIENT REVIEWS!

Our trained team will deliver and set up this inflatable at your chosen home or venue.

Now available to hire across Leeds, Wakefield, Tingley, Morley, Lofthouse, Rothwell, Methley, Normanton, Featherstone, Pontefract, Castleford, Knottingley, Darrington, Wentbridge, Sherburn in Elmet, Selby, and surrounding areas.`,
suitability:['Suitable For Children','Suitable For Adults','Indoors on Hard Surface','Outdoors on Grass','Outdoors on Hard Surface'],
// size:['Unit Size:	15ft	12ft	9.5ft','Required Space:	21ft	15ft	10ft'],
},

{
  price: 175.99 +125,
  bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-pink.png",
  title: "Adults Cars Themed Bouncy Castle - Green & Light Blue",
  img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_300/0493dfc6ed6591e809fb52089155b17a",
  description: `
**Introducing our Adults Cars Themed Bouncy Castle!** This is one of our new purchases and additions to our outstanding premium 2024 fleet.

The Cars Themed bouncy castle is an amazing addition to any birthday party or event, showcasing classic cartoon cars artwork with a modern gloss finish that matches the premium gloss on all our inflatables.

**Enhance Your Event:** 
Why not take your special event to the next level by adding the ultimate bouncy castle upgrade, which includes disco lights and a big Bluetooth speaker?

This bouncy castle is ideal for all your indoor and outdoor events and special occasions. It can easily be paired with slides, ball pools, soft play, and matching mat setups to create an incredible package.

**Service:** 
Our trained team will deliver and set up this inflatable at your home or chosen venue.

**Available for Hire Across:**
Leeds, Wakefield, Tingley, Morley, Lofthouse, Rothwell, Methley, Normanton, Featherstone, Pontefract, Castleford, Knottingley, Darrington, Wentbridge, Sherburn in Elmet, Selby, and surrounding areas.`,
size:['15ft,12ft,9.5ft','21ft,15ft,10ft'],
suitability:['Indoors on Hard Surface','Outdoors on Artificial Grass','Outdoors on Flags','Outdoors on Grass','Outdoors on Hard Surface'],
}
,
{
  price: 105.99 +125,
  bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-pink.png",
  title: "Superheroes Bouncy Castle - Green & Light Blue",
  img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_300/303c7e7fd9dd0cd42d9484c6c9877fa8",
  description: `
**Introducing the Superheroes Bouncy Castle!** Premium Inflatables is your local choice for bouncy castle hire, rated number #1 on Google Reviews for Leeds, Wakefield, and surrounding areas.

We deliver a choice of the UK's latest and most on-trend bouncy castles, all part of our outstanding Premium 2024 Fleet!

**Quality Assurance:** 
Never settle for lower-quality services offering older, cheap bouncy castles for hire!

Our under 5's / Toddlers Superheroes Themed bouncy castle is an amazing addition to any birthday party or event, featuring classic cartoon artwork finished in a modern gloss to match the premium gloss on all our inflatables.

**Ideal for All Occasions:** 
The Superheroes bouncy castle is perfect for both indoor and outdoor events. It can easily be paired with matching toddler slides, ball pools, soft play, and mats to create an incredible premium deluxe package.

**Why Choose Premium Inflatables?** 
- RPii trained team for safe delivery and setup at your chosen venue.
- Now available to hire across Leeds, Wakefield, Tingley, Morley, Lofthouse, Rothwell, Methley, Normanton, Featherstone, Pontefract, Castleford, Knottingley, Darrington, Wentbridge, Sherburn in Elmet, Selby, and surrounding areas.

**Check Our Reviews:** 
CLICK HERE TO SEE OUR GOOGLE CLIENT REVIEWS FEEDBACK`,
size:['9ft,11.5ft,8ft','12ft,17ft,8.5ft'],
suitability:['Indoors on Hard Surface','Outdoors on Artificial Grass','Outdoors on Flags','Outdoors on Grass','Outdoors on Hard Surface'],

}
,
{
  price: 135.99 +125,
  bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-pink.png",
  title: "Mermaids Bouncy Castle - Pink & Purple",
  img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_300/718108814488107da6aca8edd7d2eac5",
  description: `
**100% Five-Star Reviews Delivering on All Promises**
At Premium Inflatables, our commitment to excellence is reflected in our 100% five-star rating on Google. With hundreds of reviews from satisfied customers, we pride ourselves on consistently delivering premium products and services. This unparalleled reputation sets us apart and ensures your event is in the hands of trusted professionals.

**Premium Guarantees:**
- New fully sanitized 2024 Premium Inflatables & accessories
- On-time deliveries every time!
- Punctual collections
- Friendly, approachable RPii trained team dedicated to making your event safe and successful!
- Around-the-clock customer service to answer all your calls and messages.

It is our duty to help create the best birthday bouncy castle parties of 2024!

**Stress-Free Planning:**
We understand that organizing your children's special day can be stressful. Once booked with Premium Inflatables, you can rest assured that your Premium Bouncy Castles, Slides, and Soft Play will be one less thing to worry about. Our services are unmatched!

**Never Settle for Less:**
Never confuse us with lower-quality services offering older, cheap bouncy castles for hire!

**New 2024 Mermaids Theme Bounce N' Slide:**
The Mermaids Themed bouncy castle with slide is an amazing addition to any birthday party or event, featuring classic cartoon mermaid artwork finished in modern gloss to match the premium look of all our inflatables.

**Upgrade Options:**
Why not take your special event to the next level by adding the ultimate bouncy castle upgrade, including disco lights and a big Bluetooth speaker?

This bouncy castle with slide is ideal for all your indoor and outdoor events and can be paired with ball pools, soft play, and matching mats to create an incredible package catering to various age groups.

**Custom Themes Available:**
If you have a different theme for your daughter’s birthday party, we’ve got you covered! Check out our themed versions of this Bounce N' Slide Bouncy Castle with Slide Combo:
- Pink/Purple Plain No Theme
- Butterflies
- Happy Birthday
- Mermaids
- Party Time Pink Celebrations
- Party Time Blue Celebrations
- Princess
- Sea World
- Unicorn

**Matching Premium Packages:**
This Bounce N' Slide bouncy castle can be part of our 'Bounce N' Slide Castle Soft Play Packages,' perfectly designed for mixed-age groups from toddlers to teens, available in plain or themed options.

**Why Choose Premium Inflatables Bouncy Castle Hire Wakefield?**
CLICK HERE TO SEE OUR GOOGLE CLIENT REVIEWS FEEDBACK

Our RPii trained team will deliver and set up this premium inflatable at your chosen home or venue across Leeds, Wakefield, Tingley, Morley, Lofthouse, Rothwell, Methley, Normanton, Featherstone, Pontefract, Castleford, Knottingley, Darrington, Wentbridge, Sherburn in Elmet, Selby, and surrounding areas.`,
size:['12ft,16ft,9.5ft','16ft,22ft,10ft','3ft'],
suitability:['Suitable For Children','Not Suitable For Adults','Indoors on Hard Surface','Outdoors on Grass','Outdoors on Hard Surface'],
}
,
 
{
  price: 175.99 +125,
  bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-pink.png",
  title: "Adults Dinosaurs Themed Bouncy Castle - Red & Blue",
  img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_300/acb89bc2783214a3662208464b6a7f38",
  description: `
**Introducing Our New Dinosaurs Themed Bouncy Castle!**
One of our latest additions to the outstanding premium 2024 fleet!

The Dinosaurs Themed bouncy castle is an amazing addition to any birthday party or event, featuring classic cartoon dinosaur artwork finished in a modern gloss that matches the premium look of all our inflatables.

**Ultimate Upgrade Options:**
If this incredible inflatable wasn't already good enough, why not take your special event to the next level? Add the ultimate bouncy castle upgrade to include disco lights and a big Bluetooth speaker!

**Versatile for Any Occasion:**
The Dinosaurs Themed bouncy castle is ideal for all your indoor and outdoor events and special occasions. This castle can be easily paired with slides, ball pools, soft play, and matching mat setups to create an incredible package.

**Professional Setup:**
Our trained team will deliver and set up this inflatable at your home or chosen venue.

**Available Across Multiple Locations:**
Premium Inflatables are now available to hire across Leeds, Wakefield, Tingley, Morley, Lofthouse, Rothwell, Methley, Normanton, Featherstone, Pontefract, Castleford, Knottingley, Darrington, Wentbridge, Sherburn in Elmet, Selby, and surrounding areas.`,
size:['15ft,12ft,9.5ft','21ft,15ft,10ft'],
suitability:['Indoors on Hard Surface','Outdoors on Artificial Grass','Outdoors on Flags','Outdoors on Grass','Outdoors on Hard Surface'],

}
,
  
{
  price: 175.99 +125,
  bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-pink.png",
  title: "Adults Christmas Theme Bouncy Castle Hire - Green & Light Blue",
  img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_300/fb374af97a85ab256772d4a8222d2dd7",
  description: `
**Adults Bouncy Castle Hire**

**New 2024 Premium Model Includes Bluetooth Speaker**

The New 2024 Adults / Any Age Premium Bouncy Castle is now available to hire at Premium Inflatables.

**Adults Bouncy Castle Measurements:**
- Width: 15ft
- Length: 15ft
- Height: 11.5ft

**Party Time Birthday Bouncy Castle Celebrations Theme**
The Party Time Themed bouncy castle is an amazing addition to any birthday party or event, featuring classic cartoon party time celebrations artwork finished in a modern gloss to match the premium look of our new fleet of 2024 Premium Inflatables.

This castle is ideal for all your indoor birthday bouncy castle parties and outdoor events. It can easily be paired with our range of inflatable slides, action games, and assault courses.

**Promotional Price Premium Packages**
Don’t forget to check out our promotional price packages with savings of £££'s!

**100% Five-Star Review Rated - A Testimony to Excellence**
At Premium Inflatables, our commitment to excellence is reflected in our 100% five-star rating on Google. With hundreds of reviews from satisfied customers, we take pride in consistently delivering premium products and service. This unparalleled reputation sets us apart from the competition and ensures that your event is in the hands of trusted professionals.

**Guaranteed Turn Up & Delivery**
Premium Inflatables, Yorkshire's number #1 leaders in the inflatable hire industry, offer delivery across all of Leeds, Wakefield, Tingley, Morley, Lofthouse, Rothwell, Methley, Normanton, Featherstone, Pontefract, Castleford, Knottingley, Darrington, Wentbridge, Sherburn in Elmet, Selby, and surrounding areas.`,
size:['15ft,12ft,9.5ft','21ft,15ft,10ft'],
suitability:['Indoors on Hard Surface','Outdoors on Artificial Grass','Outdoors on Flags','Outdoors on Grass','Outdoors on Hard Surface'],

},
{
  Price: 175,
  bgImg: "https://files.bookingonline.co.uk/image/upload/f_auto/themes/009/castle-pink.png",
  title: "Adults Christmas Theme Bouncy Castle Hire - Green & Light Blue",
  img: "/cProduct/C1.png",
   description:`Adults Christmas Theme Bouncy Castle Hire - Green & Light Blue

Adults Bouncy Castle Hire
New 2024 Premium Model includes Bluetooth Speaker
The New 2024 Adults / Any Age Premium Bouncy Castle now available to hire at Premium Inflatables

Adults Bouncy Castle Measurements
Wide - 15ft
Length - 15ft
Height - 11.5ft
Party Time Birthday Bouncy Castle Celebrations Theme
The Party Time Themed bouncy castle is a amazing addition to any birthday party or event, boasting the classic cartoon party time 
celebrations artwork which is finished in a modern gloss to match the premium gloss finish on all our new fleet of 2024 Premium Inflatables.
The Party Time Themed bouncy castle is Ideal for all your indoor birthday bouncy castle parties and outdoor events.
This castle can be easily paired with our range of Inflatable Slides, Inflatable Action Games and Inflatable Assault Courses
Do not forget to check out our Promotional Price Premium Packages with savings of £££'s !!

100% Five-Star Review Rated - A Testimony to Excellence
At Premium Inflatables, our commitment to excellence is reflected in our 100% five-star rating on Google. With hundreds of reviews 
from satisfied customers, we take pride in consistently delivering premium products and service. This unparalleled reputation sets 
us apart from the competition and ensures that your event is in the hands of trusted professionals. Have our RPii trained team deliver 
and setup this inflatable at your chosen home or venue.

100% Guaranteed Turn Up & Delivery
Premium Inflatable Yorkshire's number #1 leaders in the inflatable hire industry offer delivery across all of Leeds, Wakefield, Tingley, 
Morley, Lofthouse, Rothwell, Methley, Normanton, Featherstone, Pontefract, Castleford, Knottingley, Darrington, Wentbridge, Sherburn in Elmet, 
Selby & surroundings.`,

size:['15ft,15ft,11.5ft','18ft,21ft,12ft'],
suitability:['Indoors on Hard Surface	','Outdoors on Artificial Grass','Outdoors on Flags	','Outdoors on Grass','Outdoors on Hard Surface'],

},
{
  price: 175,
  bgImg: "/cProduct/C2.png",
  title: "One of our new purchases and additions to our outstanding premium 2024 fleet!!",
  img: "/cProduct/C2.png",
   description:`The Party Time Themed bouncy castle is a amazing addition to any birthday party or event, 
boasting the classic cartoon party time artwork which is finished in a modern gloss to match
 the premium gloss finish on all our inflatables.

If this amazing inflatable wasn't already good enough why not take your special event to the
 next level by adding the ultimate bouncy castle upgrade to include disco light's & big Bluetooth speaker.

The Party Time Themed bouncy castle is Ideal for all your indoor and outdoor events and special 
occasions. This castle can be easily paired with slides, ball pools, soft play and matching mat set up to make an incredible package.

Have our trained team deliver and setup this inflatable at your home or chosen venue.

Premium Inflatables now available to hire across Leeds, Wakefield, Tingley, Morley, Lofthouse, 
Rothwell, Methley, Normanton, Featherstone, Pontefract, Castleford, Knottingley, Darrington, 
Wentbridge, Sherburn in Elmet, Selby & surroundings.`,

size:['15ft,12ft,9.5ft',
  '21ft,15ft,10ft'],
suitability:['Indoors on Hard Surface',	
  'Outdoors on Artificial Grass',	
  'Outdoors on Flags',	
  'Outdoors on Grass	', 
  'Outdoors on Hard Surface'],

},



{
  price: 135,
  bgImg: "/cProduct/Adults Christmas Theme Bouncy Castle Hire - Pink & Purple.png",
  title: "Premium Inflatables your local bouncy castle hire near you. Number #1 Google Review Rated Bouncy Castle Hirer for Leeds and Wakefield and surroundings.",
  img: "/cProduct/C3.png",
   description:`Delivering you a choice of UK's latest most on trend new purchases and additions to our outstanding Premium 2024 Fleet!!

Never to be mistaken with lesser lower services offering low quality older cheap bouncy castles for hire!!

The Christmas bouncy castle is an amazing addition to any birthday party or event, boasting the classic cartoon cars artwork
 which is finished in a modern gloss to match the premium gloss finish on all our inflatables.

If this amazing inflatable wasn't already good enough why not take your special event to the next level by adding our Premium 
Entertainment Experience the ultimate bouncy castle upgrade to include disco light's & big Bluetooth speaker.

The Christmas Themed bouncy castle is Ideal for all your indoor and outdoor events and special occasions. This castle can be 
easily paired with slides, ball pools, soft play and matching mat set up to make an incredible package.

Safety and Hygiene are the Paramount Priority here at Premium Inflatables!!
All our Premium inflatables, Soft Play, Ball Pools, Balls, Mats come fully sanitised for every use.
Why Choose Premium Inflatables Bouncy Castle Hire Wakefield?
CLICK HERE TO SEE OUR GOOGLE CLIENT REVIEWS FEEDBACK

Have our trained team deliver and setup this inflatable at your chosen home or venue

Now available to hire across Leeds, Wakefield, Tingley, Morley, Lofthouse, Rothwell, Methley, Normanton, Featherstone, Pontefract, 
Castleford, Knottingley, Darrington, Wentbridge, Sherburn in Elmet, Selby & surroundings.`,

size:['12ft,15ft,9.5ft',
  '15ft,21ft,10ft','3.7m,4.6m,2.9m','4.6m,6.4m,3.0m'],
suitability:['Suitable For Children',	
  'Not Suitable For Adults'	,
  'Suitable For',
  'Indoors on Hard Surface',	
  'Outdoors on Grass',	
  'Outdoors on Hard Surface',	
  'Not Suitable For',
  'Outdoors on Artificial Grass',	
  'Outdoors on Flags'],

  additionalInformation :"If you'd like to speak with us, call on 0113 460 138 alternatively email us at info@premiuminflatables.co.uk or take a look at our contact page You can also make a booking online using the 'Check Availability' and 'Book Online' buttons!"
}
,


{
  price: 135,
  bgImg: "/cProduct/Adults Christmas Theme Bouncy Castle Hire - Pink & Purple.png",
  title: "Premium Inflatables your local bouncy castle hire near you. Number #1 Google Review Rated Bouncy Castle Hirer for Leeds and Wakefield and surroundings.",
  img: "/cProduct/C4.png",
   description:`Delivering you a choice of UK's latest m32003ost on trend new purchases and additions to our outstanding Premium 2024 Fleet!!

Never to be mistaken with lesser lower services offering low quality older cheap bouncy castles for hire!!

The Christmas Theme bouncy castle is an amazing addition to any birthday party or event, a modern gloss to match the premium 
gloss finish on all our inflatables.

If this amazing inflatable wasn't already good enough why not take your special event to the next level by adding our Premium 
Entertainment Experience the ultimate bouncy castle upgrade to include disco light's & big Bluetooth speaker.

The Christmas Theme bouncy castle is ideal for all your indoor and outdoor events and special occasions. This castle can be easily 
paired with slides, ball pools, soft play and matching mat set up to make an incredible package.

Our new purchases and additions to our outstanding premium 2024 fleet!!

The Christmas Theme bouncy castle is an amazing addition to any birthday party or event, a modern gloss to match the premium gloss
 finish on all our inflatables.

If this amazing inflatable wasn't already good enough why not take your special event to the next level by adding our Premium 
Entertainment Experience the ultimate bouncy castle upgrade to include disco light's & big Bluetooth speaker.

The Christmas Theme bouncy castle is Ideal for all your indoor and outdoor events and special occasions. This castle can be easily 
paired with slides, ball pools, soft play and matching mat set up to make an incredible package.

Safety and Hygiene are the Paramount Priority here at Premium Inflatables!!
All our Premium inflatables, Soft Play, Ball Pools, Balls, Mats come fully sanitised for every use.
Why Choose Premium Inflatables Bouncy Castle Hire Wakefield?
CLICK HERE TO SEE OUR GOOGLE CLIENT REVIEWS FEEDBACK

Have our trained team deliver and setup this inflatable at your chosen home or venue

Now available to hire across Leeds, Wakefield, Tingley, Morley, Lofthouse, Rothwell, Methley, Normanton, Featherstone, Pontefract, 
Castleford, Knottingley, Darrington, Wentbridge, Sherburn in Elmet, Selby & surroundings.`,

size:['12ft,15ft,9.5ft',
  '15ft,21ft,10ft','3.7m,4.6m,2.9m',
    '4.6m,6.4m,3.0m','0.9m'	],
suitability:['Indoors on Hard Surface',	
  'Outdoors on Grass',	
  'Outdoors on Hard Surface',
  'Not Suitable For',
  'Outdoors on Artificial Grass',	
  'Outdoors on Flags'],

  additionalInformation :"If you'd like to speak with us, call on 0113 460 138 alternatively email us at info@premiuminflatables.co.uk or take a look at our contact page You can also make a booking online using the 'Check Availability' and 'Book Online' buttons!",
  users:['Max Users @ 1.0	        7',
    'Max Users @ 1.25	6',
    'Max Users @ 1.5	        4',
    'Max Users @ 1.8	        4']
}
,

{
  price: 175,
 Offer :145,
  bgImg: "/cProduct/C5.png",
  title: "3D Dinosaur Bouncy Castle With Front Slide",
  img: "/p3i/P1.png",
  images:['/p3i/p2.png','/p3i/p3.png','/p3i/p4.png','/p3i/p5.png'],
   description:`https://youtu.be/s2w_4OBgKs8`,

size:['12ft,15ft,9.5ft',
  '','3.7m,4.6m,2.9m'	],
suitability:['Not Suitable For Adults','Indoors on Hard Surface',	
  'Outdoors on Artificial Grass',	
  'Outdoors on Flags',	
  'Outdoors on Grass',	
  'Outdoors on Hard Surface'],

  additionalInformation :"If you'd like to speak with us, call on 0113 460 138 alternatively email us at info@premiuminflatables.co.uk or take a look at our contact page You can also make a booking online using the 'Check Availability' and 'Book Online' buttons!",
  users:['Max Users @ 1.0	        6',
    'Max Users @ 1.25	5',
    'Max Users @ 1.5	        4',
    'Max Users @ 1.8	        4',]
},



{
  price: 175,
  Offer: 145,
  bgImg: "/p3i/Adults Christmas Theme Bouncy Castle Hire - Pink & Purple.png",
  title: "3D Lion Bouncy Castle With Front Slide",
  img: "/p3i/p6.png",
  images:['/p3i/p2.png','/p3i/p3.png','/p3i/p4.png','/p3i/p5.png'],
   description:`3D Lion Jungle Theme Bounce N' Slide
Contact Premium Inflatables
It couldn't be easier to get in touch with the team here at Premium inflatables. 
You can use the contact form or:

Call our office on: 0113 460 1386
Mobile / WhatsApp / Text - us on: 07482511995
Email us at: info@premiuminflatables.co.uk`,

size:[' 12ft,16ft,9.5ft',
  '16ft,22ft,10ft','4.9m,6.7m,3.0m','3.7m,4.9m,2.9m'	],
suitability:['Not Suitable For Adults	','Indoors on Hard Surface',	
  'Outdoors on Artificial Grass',	
  'Outdoors on Flags',	
  'Outdoors on Grass',	
  'Outdoors on Hard Surface'],

  additionalInformation :"If you'd like to speak with us, call on 0113 460 138 alternatively email us at info@premiuminflatables.co.uk or take a look at our contact page You can also make a booking online using the 'Check Availability' and 'Book Online' buttons!",
  users:['Max Users @ 1.0	        6',
    'Max Users @ 1.25	5',
    'Max Users @ 1.5	        4',
    'Max Users @ 1.8	        4',]
},


{
  price: 175,
  Offer: 145,
  bgImg: "/p3i/3DDinosaurBouncyCastleWithFrontSlide.png",
  title: "3D Monster Truck Bouncy Castle With Front Slide",
  img: "/p3i/p8.png",
  images:['/p3i/p7.png','/p3i/p8.png','/p3i/p9.png'],
   description:`3D Unicorn Bounce N' Slide
Available to hire from November
Click Here For Reservations
Contact Premium Inflatables
It couldn't be easier to get in touch with the team here at 
Premium inflatables. You can use the contact form or:

Call our office on: 0113 460 1386
Mobile / WhatsApp / Text - us on: 07482511995
Email us at: info@premiuminflatables.co.uk`,

size:[' 12ft,	15ft	,9.5ft',
  '3.7m	,4.6m	,2.9m'	],
suitability:['Suitable For',
  'Indoors on Hard Surface'	,
  'Outdoors on Artificial Grass',	
  'Outdoors on Flags',	
  'Outdoors on Grass',	
  'Outdoors on Hard Surface'],

  additionalInformation :"If you'd like to speak with us, call on 0113 460 138 alternatively email us at info@premiuminflatables.co.uk or take a look at our contact page You can also make a booking online using the 'Check Availability' and 'Book Online' buttons!",
  users:['Max Users @ 1.0	        6',
    'Max Users @ 1.25	5',
    'Max Users @ 1.5	        4',
    'Max Users @ 1.8	        4',]
},


{
  price: 175,
  Offer: 145,
  bgImg: "/p3i/3DDinosaurBouncyCastleWithFrontSlide.png",
  title: "Bounce N' Slide Soft Play Package - Red / Blue",
  img: "/p3i/p8.png",
  images:['/p3i/p7.png','/p3i/p8.png','/p3i/p9.png'],
   description:`3D Unicorn Bounce N' Slide
Available to hire from November
Click Here For Reservations
Contact Premium Inflatables
It couldn't be easier to get in touch with the team here at 
Premium inflatables. You can use the contact form or:

Call our office on: 0113 460 1386
Mobile / WhatsApp / Text - us on: 07482511995
Email us at: info@premiuminflatables.co.uk`,

size:[' 12ft,	15ft	,9.5ft',
  '3.7m	,4.6m	,2.9m'	],
suitability:['Suitable For',
  'Indoors on Hard Surface'	,
  'Outdoors on Artificial Grass',	
  'Outdoors on Flags',	
  'Outdoors on Grass',	
  'Outdoors on Hard Surface'],

  additionalInformation :"If you'd like to speak with us, call on 0113 460 138 alternatively email us at info@premiuminflatables.co.uk or take a look at our contact page You can also make a booking online using the 'Check Availability' and 'Book Online' buttons!",
  users:['Max Users @ 1.0	        6',
    'Max Users @ 1.25	5',
    'Max Users @ 1.5	        4',
    'Max Users @ 1.8	        4',]
},


{
  price: 245,
  Offer: 195,
  bgImg: "",
  title: "The Mega Soft Play Plain Red/Blue Castle with Slide Package",
  img: "/newProducts/bounceSlide.png",
  images: ['/newProducts/bounceSlide.png','/newProducts/bounceSlide.png'],
  description: `The bouncy castle with slide is 12x16ft is ideal for all your indoor and outdoor events and special occasions. This castle is paired with a foam ball pool, 17 pieces of soft play, and matching 9 mat set up to make an incredible package. Contact Premium Inflatables to make a booking:
Call: 0113 460 1386
Mobile / WhatsApp / Text: 07482511995
Email: info@premiuminflatables.co.uk`,

  size: ['12ft, 16ft, 9.5ft', '3.7m, 4.9m, 2.9m'],
  suitability: [
    'Suitable For',
    'Indoors on Hard Surface',
    'Outdoors on Artificial Grass',
    'Outdoors on Flags',
    'Outdoors on Grass',
    'Outdoors on Hard Surface',
    'Children (Not Suitable For Adults)'
  ],
  
  additionalInformation: `We do not hire our soft play & foam ball pools for outdoor use. Please make enquiries for alternatives on our Contact Page. If you'd like to speak with us, call on 0113 460 1386 or email us at info@premiuminflatables.co.uk. You can also make a booking online using the 'Check Availability' and 'Book Online' buttons!`,
  
  users: [
    'Max Users @ 1.0    6',
    'Max Users @ 1.25   5',
    'Max Users @ 1.5    4',
    'Max Users @ 1.8    4'
  ],

  additionalDetails: {
    "Required Space": ["16ft, 22ft, 10ft", "4.9m, 6.7m, 3.0m"],
    "Required Access Width": ["3ft", "0.9m"],
    "Unit Size": ["12ft, 16ft, 9.5ft", "3.7m, 4.9m, 2.9m"]
  },

  extras: [
    'Foam Ball Pool',
    'Soft Play 18pc & 9xMega Mat Set Up - Red / Blue',
    'Add Didi Cars and Hoppers for extra fun!'
  ],

  regionsAvailable: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 'Rothwell', 
    'Methley', 'Normanton', 'Featherstone', 'Pontefract', 'Castleford', 
    'Knottingley', 'Darrington', 'Wentbridge', 'Sherburn in Elmet', 'Selby'
  ]
}
,

{
  price: 245,
  Offer: null,
  bgImg: "/p3i/.png",
  title: "Butterflies Bounce N' Slide Soft Play Package - Pink / Purple",
  img: "/newProducts/Butterflies Bounce N' Slide Soft Play PackagePink Purple3.png",
  images: ["/newProducts/Butterflies Bounce N' Slide Soft Play PackagePink Purple3.png", "/newProducts/Butterflies Bounce N' Slide Soft Play PackagePink Purple5.png", "/newProducts/Butterflies Bounce N' Slide Soft Play PackagePink Purple6.png","/newProducts/Butterflies Bounce N' Slide Soft Play PackagePink Purple7.png","/newProducts/Butterflies Bounce N' Slide Soft Play PackagePink Purple8.png","/newProducts/Butterflies Bounce N' Slide Soft Play PackagePink Purple9.png","/newProducts/Butterflies Bounce N' Slide Soft Play PackagePink Purple10.png","/newProducts/Butterflies Bounce N' Slide Soft Play PackagePink Purple7.png"],
  description: `Introducing our new Amazing Mega Pink and Purple Butterflies Soft Play
  Package for all your beautiful little girls out there!!

  It contains our highly sort after 12ft x 16ft x 9.5ft (Width/Length/Height)
  Bouncy Castle with slide combination it has the pretty and colourful butterfly
  theme on the Castle, it is paired with our foam ball pool,9x Mega Mat set up with matching 17 pieces of soft play!

  *We do not hire our soft play & foam ball pools for outdoor use please make enquiries
  for alternatives on our Contact Page If you'd like to speak with us, call on 0113 460 1386 
  alternatively email us at info@premiuminflatables.co.uk`,
  size: ['12ft, 16ft, 9.5ft', '3.7m, 4.9m, 2.9m'],
  suitability: [
    'Suitable For',
    'Indoors on Hard Surface',
    'Outdoors on Artificial Grass',
    'Outdoors on Flags',
    'Outdoors on Grass',
    'Outdoors on Hard Surface'
  ],
  additionalInformation: "If you'd like to speak with us, call on 0113 460 1386 or email us at info@premiuminflatables.co.uk. You can also make a booking online using the 'Check Availability' and 'Book Online' buttons!",
  users: [
    'Max Users @ 1.0 6',
    'Max Users @ 1.25 5',
    'Max Users @ 1.5 4',
    'Max Users @ 1.8 4'
  ],
  dimensions: {
    unitSize: { width: '12ft', length: '16ft', height: '9.5ft' },
    requiredSpace: { width: '16ft', length: '22ft', height: '10ft' },
    requiredAccessWidth: '3ft',
  },
  metricDimensions: {
    unitSize: { width: '3.7m', length: '4.9m', height: '2.9m' },
    requiredSpace: { width: '4.9m', length: '6.7m', height: '3.0m' },
    requiredAccessWidth: '0.9m'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ]
}
,
{
  price: 295,
  Offer: null,
  bgImg: "",
  title: "Butterflies Soft Play + Slide + Bouncy Castle - Pink / Purple",
  img: "/newProducts/Butterflies Soft Play + Slide + BouncyCastlePinkPurple.png",
  images: ['/newProducts/Butterflies Soft Play + Slide + BouncyCastlePinkPurple'],
  description: `Our Amazing Super Size Soft Play Package Pink and Purple Butterflies
  Theme for all your beautiful butterflies lovers out there. They can
  flutter all around this amazing set up to their hearts content, it will
  certainly keep them entertained! It contains our highly sort after 9x11ft
  Bouncy Castle with the butterfly theme, Juniors 5ft platform glossy Pink
  slide also the foam ball pool, 9x Mega Mat set up with matching pink/purple
  18 pieces of soft play!

  *We do not hire our soft play & foam ball pools for outdoor use. For alternatives, 
  make enquiries on our Contact Page. Call on 0113 460 1386 or email at info@premiuminflatables.co.uk.`,
  size: ['9ft, 11.5ft, 8ft', '2.7m, 3.5m, 2.4m'],
  suitability: [
    'Suitable For',
    'Indoors on Hard Surface',
    'Outdoors on Artificial Grass',
    'Outdoors on Flags',
    'Outdoors on Grass',
    'Outdoors on Hard Surface'
  ],
  additionalInformation: "For enquiries, call 0113 460 1386 or email info@premiuminflatables.co.uk. You can also make a booking online using the 'Check Availability' and 'Book Online' buttons!",
  users: [
    'Max Users @ 1.0 6',
    'Max Users @ 1.25 5',
    'Max Users @ 1.5 4',
    'Max Users @ 1.8 4'
  ],
  dimensions: {
    unitSize: { width: '9ft', length: '11.5ft', height: '8ft' },
    requiredSpace: { width: '12ft', length: '17ft', height: '8.5ft' },
    requiredAccessWidth: '3ft',
    slidePlatformHeight: '5ft'
  },
  metricDimensions: {
    unitSize: { width: '2.7m', length: '3.5m', height: '2.4m' },
    requiredSpace: { width: '3.7m', length: '5.2m', height: '2.6m' },
    slidePlatformHeight: '1.5m',
    requiredAccessWidth: '0.9m'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ]
}
,


{
  price: 195,
  Offer: null,
  bgImg: "/p3i/ButterfliesBouncyCastleJuniorsPackage.png",
  title: "Butterflies Soft Play Bouncy Castle Juniors Package - Pink / Purple",
  img: "/newProducts/Butterflies Soft Play Bouncy Castle Juniors Package - Pink Purple.png",
  images: ["/newProducts/Butterflies Soft Play Bouncy Castle Juniors Package - Pink Purple1.png","/newProducts/Butterflies Soft Play Bouncy Castle Juniors Package - Pink Purple2.png","/newProducts/Butterflies Soft Play Bouncy Castle Juniors Package - Pink Purple.png","/newProducts/Butterflies Soft Play Bouncy Castle Juniors Package - Pink Purple2.png"],
  description: `This Butterflies Bouncy Castle & Ball pool, Soft Play Package is made
  for all your beautiful little girls out there! This pretty Pink and Purple Bouncy castle 
  includes a foam ball pool with complimentary Purple/Silver Commercial Balls and matching 
  soft play so they can run, roll and play to their hearts content.
  
  This package is a must for Indoor Birthday Parties. Create and make their dreams come true
  in this girly pink/purple butterfly fantasy land!
  
  Butterflies Bouncy Castle 9ft x 11ft
  Foam Ball Pool
  Matching Soft Play
  
  *We do not hire our soft play & foam ball pools for outdoor use. For alternatives, 
  make enquiries on our Contact Page. Call on 0113 460 1386 or email at info@premiuminflatables.co.uk.`,
  size: ['9ft, 11.5ft, 8ft', '2.7m, 3.5m, 2.4m'],
  suitability: [
    'Suitable For',
    'Indoors on Hard Surface',
    'Outdoors on Artificial Grass',
    'Outdoors on Flags',
    'Outdoors on Grass',
    'Outdoors on Hard Surface'
  ],
  additionalInformation: "For enquiries, call 0113 460 1386 or email info@premiuminflatables.co.uk. You can also make a booking online using the 'Check Availability' and 'Book Online' buttons!",
  users: [
    'Max Users @ 1.0 6',
    'Max Users @ 1.25 5',
    'Max Users @ 1.5 4',
    'Max Users @ 1.8 4'
  ],
  dimensions: {
    unitSize: { width: '9ft', length: '11.5ft', height: '8ft' },
    requiredSpace: { width: '12ft', length: '17ft', height: '8.5ft' },
    requiredAccessWidth: '3ft'
  },
  metricDimensions: {
    unitSize: { width: '2.7m', length: '3.5m', height: '2.4m' },
    requiredSpace: { width: '3.7m', length: '5.2m', height: '2.6m' },
    requiredAccessWidth: '0.9m'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  videoLink: "https://youtu.be/aft2d6uo0tI"
}
,
{
  price: 245,
  nextMorningCollection: 50,
  title: "Butterflies Soft Play Bouncy Castle Package - Pink / Purple",
  img: "/newProducts/Butterflies Soft Play Bouncy Castle Package - PinkPurple1.png",
  images: [
    "/newProducts/butterFliesBounce.png",
    "/newProducts/ButterfliesBounceNSlideSoft PlayPackagePinkPurple4.png",
    "/newProducts/butterFly.png"
  ],
  description: `Wow, look at this Mega Pink and Purple Butterflies Soft Play Package for all your beautiful little girls out there! 
  It contains our highly sought-after 12x15ft Bouncy Castle with the butterfly theme, along with a foam ball pool, 
  a 9 Mega Mat setup with matching 17 pieces of soft play. 
  This package is a must for indoor birthday celebrations, creating a pretty party space for your little girls.`,
  safetyHygiene: "Safety and Hygiene are our paramount priority. All inflatables, soft play, ball pools, balls, and mats are fully sanitized after each use.",
  size: ['12ft, 15ft, 9.5ft', '3.7m, 4.6m, 2.9m'],
  suitability: [
    'Suitable For',
    'Indoors on Hard Surface',
    'Outdoors on Artificial Grass',
    'Outdoors on Flags',
    'Outdoors on Grass',
    'Outdoors on Hard Surface'
  ],
  additionalInformation: "For enquiries, call 0113 460 1386 or email info@premiuminflatables.co.uk. You can also book online using the 'Check Availability' and 'Book Online' buttons.",
  users: [
    'Max Users @ 1.0 7',
    'Max Users @ 1.25 6',
    'Max Users @ 1.5 5',
    'Max Users @ 1.8 4'
  ],
  dimensions: {
    unitSize: { width: '12ft', length: '15ft', height: '9.5ft' },
    requiredSpace: { width: '15ft', length: '21ft', height: '10ft' },
    requiredAccessWidth: '3ft'
  },
  metricDimensions: {
    unitSize: { width: '3.7m', length: '4.6m', height: '2.9m' },
    requiredSpace: { width: '4.6m', length: '6.4m', height: '3.0m' },
    requiredAccessWidth: '0.9m'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  videoLink: "https://youtu.be/aft2d6uo0tI"
}
,


{
  price: 245,
  nextMorningCollection: 50,
  title: "Cars Bounce N' Slide Soft Play Package - Red / Blue",
  img: "/newProducts/Cars Bounce N' Slide Soft Play PackageRed Blue.png",
  images: [
    "/newProducts/Cars Bounce N' Slide Soft Play PackageRedBlue1.png",
    "/newProducts/Cars Bounce N' Slide Soft Play PackageRedBlue2.png",
    "/newProducts/Cars Bounce N' Slide Soft Play PackageRedBlue3.png",
    "/newProducts/Cars Bounce N' Slide Soft Play PackageRedBlue4.png",
    "/newProducts/Cars Bounce N' Slide Soft Play PackageRedBlue5.png",
    "/newProducts/Cars Bounce N' Slide Soft Play PackageRedBlue6.png",
    "/newProducts/Cars Bounce N' Slide Soft Play PackageRedBlue7.png"
  ],
  description: `The Cars Themed Mega Soft Play Package is an amazing addition to any birthday party or event. If your boys love fast cars, then this is the castle for them! It features our classic cartoon cars artwork on a bouncy castle with a slide combination finished in a premium gloss. It also includes a foam ball pool, 17 pieces of soft play, and a matching 9-mat setup, creating an incredible package for indoor and outdoor events.`,
  safetyHygiene: "Safety and Hygiene are the Paramount Priority here at Premium Inflatables. All our Premium inflatables, Bouncy N' Slide Bouncy Castles, Soft Play, Ball Pools, Balls, and Mats come fully sanitized after every use.",
  size: ['12ft x 16ft x 9.5ft', '3.7m x 4.9m x 2.9m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Artificial Grass',
    'Outdoor on Flags',
    'Outdoor on Grass',
    'Outdoor on Hard Surface'
  ],
  additionalInformation: `We do not hire our soft play & foam ball pools for outdoor use. Please make enquiries for alternatives on our Contact Page. For enquiries, call 0113 460 1386 or email info@premiuminflatables.co.uk. You can also book online using the 'Check Availability' and 'Book Online' buttons.`,
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  dimensions: {
    unitSize: { width: '12ft', length: '16ft', height: '9.5ft' },
    requiredSpace: { width: '15ft', length: '22ft', height: '10ft' },
    requiredAccessWidth: '3ft'
  },
  metricDimensions: {
    unitSize: { width: '3.7m', length: '4.9m', height: '2.9m' },
    requiredSpace: { width: '4.6m', length: '6.7m', height: '3.0m' },
    requiredAccessWidth: '0.9m'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  videoLink: "",
}
,

{
  price: 245,
  title: "Cars Soft Play Bouncy Castle Package - Green / Light Blue",
  img: "/newProducts/Cars Soft Play Bouncy Castle PackageGreen Light Blue.png",
  images: [
    "/newProducts/Cars Soft Play Bouncy CastlePackageGreenLight Blue1.png",
   
  ],
  description: `The Cars Themed Mega Soft Play Package is an amazing addition to any birthday party or event, featuring classic cartoon cars artwork finished in a modern gloss to match the premium gloss finish on all our inflatables. This package includes a fantastic 12x15ft bouncy castle, foam ball pool, 17 pieces of soft play, and a matching 9-mat setup, making it a perfect choice for both indoor and outdoor events.`,
  safetyHygiene: "Safety and Hygiene are the Paramount Priority here at Premium Inflatables. All our Premium inflatables, Soft Play, Ball Pools, Balls, and Mats are fully sanitized after every use.",
  size: ['12ft x 15ft x 9.5ft', '3.7m x 4.6m x 2.9m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Artificial Grass',
    'Outdoor on Flags',
    'Outdoor on Grass',
    'Outdoor on Hard Surface'
  ],
  additionalInformation: `For enquiries, call 0113 460 1386 or email info@premiuminflatables.co.uk. You can also book online using the 'Check Availability' and 'Book Online' buttons.`,
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  dimensions: {
    unitSize: { width: '12ft', length: '15ft', height: '9.5ft' },
    requiredSpace: { width: '15ft', length: '21ft', height: '10ft' },
    requiredAccessWidth: '3ft'
  },
  metricDimensions: {
    unitSize: { width: '3.7m', length: '4.6m', height: '2.9m' },
    requiredSpace: { width: '4.6m', length: '6.4m', height: '3.0m' },
    requiredAccessWidth: '0.9m'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ]
}
,
{
  price: 245,
  Offer: 50,
  title: "Cars Soft Play Bouncy Castle Package - Red / Blue",
  img: "/newProducts/CarsSoftPlayBouncyCastlePackageRedBlue.png",
  images: [
    "/newProducts/CarsSoftPlayBouncyCastlePackageRedBlue1.png",
    "/newProducts/CarsSoftPlayBouncyCastlePackageRedBlue2.png",
    "/newProducts/CarsSoftPlayBouncyCastlePackageRedBlue3.png",
  
  ],
  description: `The Cars Themed Mega Soft Play Package is an amazing addition to any birthday party or event, featuring classic cartoon cars artwork finished in a modern gloss to match the premium gloss finish on all our inflatables. This package includes a fantastic 12x15ft bouncy castle, foam ball pool, 18 pieces of soft play, and a matching 9-mat setup, making it a perfect choice for both indoor and outdoor events.`,
  safetyHygiene: "Safety and Hygiene are the Paramount Priority here at Premium Inflatables. All our Premium inflatables, Soft Play, Ball Pools, Balls, and Mats are fully sanitized after every use.",
  size: ['12ft x 15ft x 9.5ft', '3.7m x 4.6m x 2.9m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Artificial Grass',
    'Outdoor on Flags',
    'Outdoor on Grass',
    'Outdoor on Hard Surface'
  ],
  additionalInformation: `For enquiries, call 0113 460 1386 or email info@premiuminflatables.co.uk. You can also book online using the 'Check Availability' and 'Book Online' buttons.`,
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  dimensions: {
    unitSize: { width: '12ft', length: '15ft', height: '9.5ft' },
    requiredSpace: { width: '15ft', length: '21ft', height: '10ft' },
    requiredAccessWidth: '3ft'
  },
  metricDimensions: {
    unitSize: { width: '3.7m', length: '4.6m', height: '2.9m' },
    requiredSpace: { width: '4.6m', length: '6.4m', height: '3.0m' },
    requiredAccessWidth: '0.9m'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ]
}

,

{
  price: 245,
  Offer: 50,
  title: "Circus Bounce N' Slide Soft Play Package - Red / Blue",
  img: "/newProducts/Circus Bouncy Castle & Matching inflatable Ball Pool.png",
  images: [
    "/newProducts/CircusBouncyCastleBallPool2.png"
  ],
  description: `Roll up Roll up! Come into our Amazing Premium Circus! This Mega Pack includes our Bouncy Slide Castle with matching Circus foam ball pool and soft play, keeping the under 5’s & toddlers entertained. Paired with a colour-coordinated Red/Blue soft play set and matching mats, this Circus Mega Package will make your birthday party unforgettable!`,
  safetyHygiene: "Safety and Hygiene are the Paramount Priority here at Premium Inflatables. All our Premium inflatables, Soft Play, Ball Pools, Balls, and Mats are fully sanitized after every use.",
  size: ['12ft x 16ft x 9.5ft', '3.7m x 4.9m x 2.9m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Artificial Grass',
    'Outdoor on Flags',
    'Outdoor on Grass',
    'Outdoor on Hard Surface'
  ],
  additionalInformation: `For enquiries, call 0113 460 1386 or email info@premiuminflatables.co.uk. You can also book online using the 'Check Availability' and 'Book Online' buttons.`,
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  dimensions: {
    unitSize: { width: '12ft', length: '16ft', height: '9.5ft' },
    requiredSpace: { width: '16ft', length: '22ft', height: '10ft' },
    requiredAccessWidth: '3ft'
  },
  metricDimensions: {
    unitSize: { width: '3.7m', length: '4.9m', height: '2.9m' },
    requiredSpace: { width: '4.9m', length: '6.7m', height: '3.0m' },
    requiredAccessWidth: '0.9m'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ]
}
,


{
  price: 195,
  nextMorningCollection: 50,
  title: "Circus Bouncy Castle & Matching Inflatable Ball Pool",
  img: "/newProducts/Circus Bouncy Castle & Matching inflatable Ball Pool1.png",
  images: [
    "/newProducts/Circus Bouncy Castle & Matching inflatable Ball Pool1.png",
    "/newProducts/Circus Bouncy Castle & Matching inflatable Ball Pool2.png",
    "/newProducts/Circus Bouncy Castle & Matching inflatable Ball Pool3.png",
    "/newProducts/Circus Bouncy Castle & Matching inflatable Ball Pool4.png",
    "/newProducts/Circus Bouncy Castle & Matching inflatable Ball Pool5.png",
    "/newProducts/Circus Bouncy Castle & Matching inflatable Ball Pool6.png",
    "/newProducts/Circus Bouncy Castle & Matching inflatable Ball Pool7.png",
    "/newProducts/Circus Bouncy Castle & Matching inflatable Ball Pool8.png",
    "/newProducts/Circus Bouncy Castle & Matching inflatable Ball Pool9.png",
    "/newProducts/Circus Bouncy Castle & Matching inflatable Ball Pool10.png",
    "/newProducts/Circus Bouncy Castle & Matching inflatable Ball Pool11.png"
  ],
  description: `The Circus Printed Themed bouncy castle and matching ball pool are amazing additions to any birthday party or event, boasting classic cartoon circus artwork finished in a modern gloss. Our premium circus-themed ball pool comes with commercial colour-coordinated balls to enhance the children's birthday party experience. Upgrade your event by adding our Premium Entertainment Experience, featuring disco lights and a big Bluetooth speaker!`,
  safetyHygiene: "Safety and Hygiene are the Paramount Priority here at Premium Inflatables! All our Premium inflatables, Circus Bouncy Castle, Circus Ball Pools, Soft Play, and Mats come fully sanitized for every use.",
  size: ['12ft x 15ft x 9.5ft', '3.7m x 4.6m x 2.9m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Grass',
    'Outdoor on Hard Surface'
  ],
  additionalInformation: `For inquiries, call 0113 460 1386 or email info@premiuminflatables.co.uk. You can also book online using the 'Check Availability' and 'Book Online' buttons.`,
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  dimensions: {
    unitSize: { width: '12ft', length: '15ft', height: '9.5ft' },
    requiredSpace: { width: '15ft', length: '21ft', height: '10ft' },
    requiredAccessWidth: '3ft'
  },
  metricDimensions: {
    unitSize: { width: '3.7m', length: '4.6m', height: '2.9m' },
    requiredSpace: { width: '4.6m', length: '6.4m', height: '3.0m' },
    requiredAccessWidth: '0.9m'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  videoLink: "https://youtu.be/swRNKBUhYHU"
}
,

{
  price: 195,
  nextMorningCollection: 50,
  title: "Circus Soft Play Bouncy Castle Juniors Package - Red Blue",
  img: "/newProducts/CircusBounceN'SlideSoftPlayPackageRedBlue.png",
  images: [
    "/newProducts/CircusBounceN'SlideSoftPlayPackageRedBlue.png",
    "/newProducts/CircusBounceN'SlideSoftPlayPackageRedBlue1.png",
    "/newProducts/CircusBounceN'SlideSoftPlayPackageRedBlue2.png",
    "/newProducts/CircusBounceN'SlideSoftPlayPackageRedBlue3.png",
    "/newProducts/CircusBounceN'SlideSoftPlayPackageRedBlue4.png",
    "/newProducts/CircusBounceN'SlideSoftPlayPackageRedBlue5.png",
    "/newProducts/CircusBounceN'SlideSoftPlayPackageRedBlue6.png",
    "/newProducts/CircusBounceN'SlideSoftPlayPackageRedBlue6.png",


  ],
  description: `We’ve carefully selected our Red and Blue Circus Mega Pack, featuring a highly demanded 9ft x 11ft bouncy castle measuring 8ft in height, perfect for all your indoor hires. This package is coupled with a foam ball pool, keeping the under 5’s & toddlers entertained, along with a 17-piece matching Circus Soft Play set and matching Red/Blue Mega Mat set, completing your Circus Mega Package fit for your Circus Birthday Party Celebrations.`,
  safetyHygiene: "Safety and Hygiene are the Paramount Priority here at Premium Inflatables! All our Premium inflatables, Soft Play, Ball Pools, Balls, Mats come fully sanitized for every use.",
  size: ['9ft x 11.5ft x 8ft', '2.7m x 3.5m x 2.4m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Grass',
    'Outdoor on Hard Surface'
  ],
  additionalInformation: `Why not add our fun 4x didi cars and 4x animal hoppers to your package? They will definitely keep your little monkeys entertained. For inquiries, call 0113 460 1386 or email info@premiuminflatables.co.uk. You can also book online using the 'Check Availability' and 'Book Online' buttons.`,
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  dimensions: {
    unitSize: { width: '9ft', length: '11.5ft', height: '8ft' },
    requiredSpace: { width: '12ft', length: '17ft', height: '8.5ft' }
  },
  metricDimensions: {
    unitSize: { width: '2.7m', length: '3.5m', height: '2.4m' },
    requiredSpace: { width: '3.7m', length: '5.2m', height: '2.6m' }
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  videoLink: "https://youtu.be/vO9JZOY8wrA"
}
,

{
  price: 245,
  title: "Circus Soft Play Bouncy Castle Package - Green / Light Blue",
  img: "/newProducts/CircusSoftPlayBouncyCastleJuniorsPackageRedBlue.png",
  images: [
    "/newProducts/CircusSoftPlayBouncyCastleJuniorsPackageRedBlue1.png",
    "/newProducts/CircusSoftPlayBouncyCastleJuniorsPackageRedBlue2.png",
    "/newProducts/CircusSoftPlayBouncyCastleJuniorsPackageRedBlue3.png",
    "/newProducts/CircusSoftPlayBouncyCastleJuniorsPackageRedBlue8.png",
    "/newProducts/CircusSoftPlayBouncyCastleJuniorsPackageRedBlue4.png",
    "/newProducts/CircusSoftPlayBouncyCastleJuniorsPackageRedBlue5.png",
    "/newProducts/CircusSoftPlayBouncyCastleJuniorsPackageRedBlue6.png",
    "/newProducts/CircusSoftPlayBouncyCastleJuniorsPackageRedBlue7.png",

  ],
  description: `We’ve carefully selected our Green and Light Blue Circus Mega Pack, featuring a highly demanded 12x15ft bouncy castle measuring 9.5ft in height, perfect for all your indoor hires. This package is coupled with a foam ball pool, keeping the under 5’s & toddlers entertained, along with a 17-piece matching Soft Play set and matching Green / Light Blue Mega Mat set, completing your Circus Mega Package fit for your Circus Theme Birthday Party Celebrations.`,
  safetyHygiene: "Safety and Hygiene are the Paramount Priority here at Premium Inflatables! All our Premium inflatables, Soft Play, Ball Pools, Balls, Mats come fully sanitized for every use.",
  size: ['12ft x 15ft x 9.5ft', '3.7m x 4.6m x 2.9m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Grass',
    'Outdoor on Hard Surface'
  ],
  additionalInformation: `Why not add our fun 4x didi cars and 4x animal hoppers to your package? They will definitely keep your little monkeys entertained. For inquiries, call 0113 460 1386 or email info@premiuminflatables.co.uk. You can also book online using the 'Check Availability' and 'Book Online' buttons.`,
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  dimensions: {
    unitSize: { width: '12ft', length: '15ft', height: '9.5ft' },
    requiredSpace: { width: '15ft', length: '21ft', height: '10ft' },
    requiredAccessWidth: '3ft'
  },
  metricDimensions: {
    unitSize: { width: '3.7m', length: '4.6m', height: '2.9m' },
    requiredSpace: { width: '4.6m', length: '6.4m', height: '3.0m' },
    requiredAccessWidth: '0.9m'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ]
}
,

{
  price: 245,
  title: "Circus Soft Play Bouncy Castle Package - Red / Blue",
  img: "/newProducts/CircusSoftPlayBouncyCastleJuniorsPackageRedBlue9.png",
  images: [
    "/newProducts/CircusSoftPlayBouncyCastleJuniorsPackageRedBlue9.png",
    "/newProducts/CircusSoftPlayBouncyCastlePackageGreenLightBlue.png",
    "/newProducts/CircusSoftPlayBouncyCastlePackageGreenLightBlue1.png",
    "/newProducts/CircusSoftPlayBouncyCastlePackageGreenLightBlue2.png",
    "/newProducts/CircusSoftPlayBouncyCastlePackageGreenLightBlue3.png",
    "/newProducts/CircusSoftPlayBouncyCastlePackageGreenLightBlue3.png",
    "/newProducts/CircusSoftPlayBouncyCastlePackageRedBlue.png",
    "/newProducts/CircusSoftPlayBouncyCastlePackageRedBlue1.png",

  ],
  description: `We’ve carefully selected our Circus Mega Pack, featuring a highly demanded 12ft x 15ft bouncy castle measuring 9.5ft in height, perfect for all your indoor hires. This package is coupled with a foam ball pool, keeping the under 5’s, toddlers, and older kids entertained, along with a 16-piece matching Circus soft play and matching mat set, completing your Circus Mega Package fit for your Birthday Party Celebrations.`,
  safetyHygiene: "Safety and Hygiene are the Paramount Priority here at Premium Inflatables! All our Premium inflatables, Soft Play, Ball Pools, Balls, Mats come fully sanitized for every use.",
  additionalCosts: {
    nextMorningCollection: 50
  },
  size: ['12ft x 15ft x 9.5ft', '3.7m x 4.6m x 2.9m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Grass',
    'Outdoor on Hard Surface'
  ],
  additionalInformation: `Why not add our fun 4x didi cars and 4x animal hoppers to your package? They will definitely keep your little monkeys entertained. For inquiries, call 0113 460 1386 or email info@premiuminflatables.co.uk. You can also book online using the 'Check Availability' and 'Book Online' buttons.`,
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  dimensions: {
    unitSize: { width: '12ft', length: '15ft', height: '9.5ft' },
    requiredSpace: { width: '15ft', length: '21ft', height: '10ft' },
    requiredAccessWidth: '3ft'
  },
  metricDimensions: {
    unitSize: { width: '3.7m', length: '4.6m', height: '2.9m' },
    requiredSpace: { width: '4.6m', length: '6.4m', height: '3.0m' },
    requiredAccessWidth: '0.9m'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ]
}
,

{
  price: 245,
  title: "Diggers Bounce N' Slide Soft Play Package - Red / Blue",
  img: "/newProducts/diggers-soft-play-bouncy-castle-package-green-light-blue.png",
  images: [
    "/newProducts/diggers-soft-play-bouncy-castle-package-green-light-blue1.png",
    "/newProducts/diggers-soft-play-bouncy-castle-package-green-light-blue2.png",
    "/newProducts/DiggersBounceN'SlideSoftPlayPackageRedBlue.png"
  ],
  description: `The Diggers Themed Mega Soft Play Package is where your little boys can jump, bounce, slide, and play at being mini Diggers! This package features a 12x16ft Diggers Bouncy Castle with Slide, foam ball pool, 18-piece soft play, and 9 matching mats. Perfect for all indoor and outdoor events and special occasions.`,
  safetyHygiene: "Safety and Hygiene are the Paramount Priority at Premium Inflatables! All our inflatables, Soft Play, Ball Pools, Balls, and Mats come fully sanitized for every use.",
  additionalCosts: {
    nextMorningCollection: 50
  },
  size: ['12ft x 16ft x 9.5ft', '3.7m x 4.9m x 2.9m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Grass',
    'Outdoor on Hard Surface'
  ],
  additionalInformation: `Why not add our fun 4x Didi cars and animal hoppers to your package? They'll keep the kids entertained throughout your party. For inquiries, call 0113 460 1386 or email info@premiuminflatables.co.uk. Book online using the 'Check Availability' and 'Book Online' buttons.`,
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  dimensions: {
    unitSize: { width: '12ft', length: '16ft', height: '9.5ft' },
    requiredSpace: { width: '15ft', length: '22ft', height: '10ft' },
    requiredAccessWidth: '3ft'
  },
  metricDimensions: {
    unitSize: { width: '3.7m', length: '4.9m', height: '2.9m' },
    requiredSpace: { width: '4.6m', length: '6.7m', height: '3.0m' },
    requiredAccessWidth: '0.9m'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ]
}
,

{
  price: 195,
  title: "Diggers Soft Play Bouncy Castle Juniors Package - Red / Blue",
  img: "/newProducts/DiggersSoftPlayBouncyCastleJuniorsPackageRedBlue.png",
  images: [
    "/newProducts/DiggersSoftPlayBouncyCastleJuniorsPackageRedBlue1.png",
    "/newProducts/DiggersSoftPlayBouncyCastleJuniorsPackageRedBlue2.png",
    "/newProducts/DiggersSoftPlayBouncyCastleJuniorsPackageRedBlue.png"
  ],
  description: `The Diggers Themed Mega Soft Play Under 5's Package offers a perfect way for little boys to bounce and play like mini Diggers! This set includes a 9ft x 11ft x 8ft bouncy castle, foam ball pool, matching 18-piece soft play set, and a 9x matching mega mat, creating a premium package ideal for toddlers.`,
  safetyHygiene: "Safety and Hygiene are the Paramount Priority at Premium Inflatables! All our inflatables, Soft Play, Ball Pools, Balls, and Mats are fully sanitized for every use.",
  additionalCosts: {
    nextMorningCollection: 50
  },
  size: ['9ft x 11.5ft x 8ft', '2.7m x 3.5m x 2.4m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Grass',
    'Outdoor on Hard Surface'
  ],
  additionalInformation: `Need more for bigger parties? Add our popular 4x Didi Cars, Hoppers, or Giant Connect 4 to keep everyone entertained. For inquiries, call 0113 460 1386 or email info@premiuminflatables.co.uk. Book online using the 'Check Availability' and 'Book Online' buttons.`,
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  dimensions: {
    unitSize: { width: '9ft', length: '11.5ft', height: '8ft' },
    requiredSpace: { width: '12ft', length: '17ft', height: '8.5ft' },
    requiredAccessWidth: '3ft'
  },
  metricDimensions: {
    unitSize: { width: '2.7m', length: '3.5m', height: '2.4m' },
    requiredSpace: { width: '3.7m', length: '5.2m', height: '2.6m' },
    requiredAccessWidth: '0.9m'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ]
}
,

{
  price: 245,
  title: "Diggers Soft Play Bouncy Castle Package - Green / Light Blue",
  img: "/newProducts/DiggersSoftPlayBouncyCastleJuniorsPackageRedBlue3.png",
  images: [
    "/newProducts/DiggersSoftPlayBouncyCastleJuniorsPackageRedBlue3.png",
    "/newProducts/DiggersSoftPlayBouncyCastleJuniorsPackageRedBlue4.png",
    "/newProducts/dinosaurs-juniors-slide-bouncy-castle-green-light-blue.png"
  ],
  description: `The Green and Light Blue Diggers Mega Pack features a 12ft x 15ft bouncy castle perfect for indoor hires with a height of 9.5ft. This package also includes a matching low-height foam ball pool and a 18-piece soft play set laid out on a mega mat. Designed to keep toddlers and under 5's entertained with its luxury gloss finish, perfect for your Diggers-themed party.`,
  safetyHygiene: "Safety and Hygiene are the Paramount Priority at Premium Inflatables! All inflatables, soft play, ball pools, balls, and mats are fully sanitized before every use.",
  additionalCosts: {
    nextMorningCollection: 50 // Optional based on the previous package
  },
  size: ['12ft x 15ft x 9.5ft', '3.7m x 4.6m x 2.9m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Grass',
    'Outdoor on Hard Surface'
  ],
  additionalInformation: `Add optional extras like 4x Didi Cars and 4x Animal Hoppers to keep the little ones entertained. For inquiries, call 0113 460 1386 or email info@premiuminflatables.co.uk. Book online using the 'Check Availability' and 'Book Online' buttons.`,
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  dimensions: {
    unitSize: { width: '12ft', length: '15ft', height: '9.5ft' },
    requiredSpace: { width: '15ft', length: '21ft', height: '10ft' },
    requiredAccessWidth: '3ft'
  },
  metricDimensions: {
    unitSize: { width: '3.7m', length: '4.6m', height: '2.9m' },
    requiredSpace: { width: '4.6m', length: '6.4m', height: '3.0m' },
    requiredAccessWidth: '0.9m'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ]
}
,

{
  price: 195,
  title: "Dinosaurs Juniors Slide + Bouncy Castle - Green / Light Blue",
  img: "/newProducts/dinosaurs-soft-play-bouncy-castle-juniors-package-green-light-blue.png",
  images: [
    "/newProducts/dinosaurs-soft-play-bouncy-castle-juniors-package-green-light-blue.png",
    "/newProducts/DinosaursJuniorsSlideBouncyCastleGreenLightBlue1.png",
    "/newProducts/DinosaursJuniorsSlideBouncyCastleGreenLightBlue2.png"
  ],
  description: `This package features a 9ft x 11.5ft Dinosaurs-themed bouncy castle combined with a juniors inflatable slide. Perfect for your indoor or outdoor party, the platform height of the slide is 5ft, making it ideal for younger children. The package is available in a stylish Green and Light Blue design with a focus on safety and hygiene.`,
  safetyHygiene: "Safety and Hygiene are the Paramount Priority at Premium Inflatables! All inflatables, soft play, ball pools, balls, and mats are fully sanitized before every use.",
  additionalCosts: {
    nextMorningCollection: 50
  },
  size: ['9ft , 11.5ft , 8ft', '2.7m , 3.5m , 2.4m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Grass',
    'Outdoor on Hard Surface'
  ],
  additionalInformation: `Add optional extras like 4x Didi Cars and 4x Animal Hoppers to keep the little ones entertained. For inquiries, call 0113 460 1386 or email info@premiuminflatables.co.uk. Book online using the 'Check Availability' and 'Book Online' buttons.`,
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  dimensions: {
    unitSize: { width: '9ft', length: '11.5ft', height: '8ft' },
    requiredSpace: { width: '12ft', length: '17ft', height: '8.5ft' },
    requiredAccessWidth: '3ft'
  },
  metricDimensions: {
    unitSize: { width: '2.7m', length: '3.5m', height: '2.4m' },
    requiredSpace: { width: '3.7m', length: '5.2m', height: '2.6m' },
    requiredAccessWidth: '0.9m'
  },
  slideDetails: {
    slideSize: { width: '12ft', length: '12ft', height: '8ft' },
    platformHeight: '5ft'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ]
}
,

{
  price: 195,
  title: "Dinosaurs Soft Play Bouncy Castle Juniors Package - Green / Light Blue",
  img: "/newProducts/dinosaurs-soft-play-bouncy-castle-juniors-package-green-light-blue1.png",
  images: [
    "/newProducts/dinosaurs-soft-play-bouncy-castle-juniors-package-green-light-blue2.png",
    "/newProducts/dinosaurs-soft-play-bouncy-castle-juniors-package-red-blue.png",
    // "/newProducts/DinosaursSoftPlayBouncyCastleGreenLightBlue2.png"
  ],
  description: `The Dinosaurs Themed Mega Soft Play Package is perfect for any birthday party or event, featuring a Dinosaurs-themed 9ft x 11ft bouncy castle paired with a ball pool, 18 pieces of soft play, and 9 matching mats. This package brings hours of fun and excitement with its vibrant Green and Light Blue design. Ideal for indoor events due to its 8ft height, it’s also perfect for outdoor use at your chosen venue.`,
  safetyHygiene: "Safety and Hygiene are our top priorities at Premium Inflatables! All inflatables, soft play, ball pools, balls, and mats are fully sanitized before every use.",
  additionalCosts: {
    nextMorningCollection: 50
  },
  size: ['9ft , 11.5ft , 8ft', '2.7m , 3.5m , 2.4m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Grass',
    'Outdoor on Hard Surface'
  ],
  ballPool: {
    description: "Foam ball pool included in the package, suitable for indoor and outdoor use.",
    size: ['Foam Ball Pool: Green / Light Blue'],
    suitability: [
      'Indoor on Hard Surface',
      'Outdoor on Grass',
      'Outdoor on Hard Surface'
    ]
  },
  softPlay: {
    description: "Includes 18 pieces of soft play with a 9x matching mat set up, perfect for toddlers and young children.",
    size: ['18pc Soft Play & 9xMega Mat Set'],
    suitability: [
      'Indoor on Hard Surface',
      'Outdoor on Grass',
      'Outdoor on Hard Surface'
    ]
  },
  extras: {
    didiCars: "Optional: 4x Didi Cars & 4x Hoppers available to keep all the children entertained.",
    connectFour: "Optional: Giant Connect 4 Game for added fun and competition."
  },
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  dimensions: {
    unitSize: { width: '9ft', length: '11.5ft', height: '8ft' },
    requiredSpace: { width: '12ft', length: '17ft', height: '8.5ft' },
    requiredAccessWidth: '3ft'
  },
  metricDimensions: {
    unitSize: { width: '2.7m', length: '3.5m', height: '2.4m' },
    requiredSpace: { width: '3.7m', length: '5.2m', height: '2.6m' },
    requiredAccessWidth: '0.9m'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ]
}
,
{
  price: 195,
  title: "Dinosaurs Soft Play Bouncy Castle Juniors Package - Red / Blue",
  img: "/newProducts/dinosaurs-soft-play-bouncy-castle-juniors-package-red-blue1.png",
  images: [
    "/newProducts/dinosaurs-soft-play-bouncy-castle-juniors-package-red-blue2.png",
    "/newProducts/dinosaurs-soft-play-bouncy-castle-juniors-package-red-blue3.png",
    "/newProducts/dinosaurs-soft-play-bouncy-castle-juniors-package-red-blue4.png",
    "/newProducts/dinosaurs-soft-play-bouncy-castle-juniors-package-red-blue5.png",
    "/newProducts/dinosaurs-soft-play-bouncy-castle-juniors-package-red-blue6.png",
    "/newProducts/dinosaurs-soft-play-bouncy-castle-package-green-light-blue.png"

  ],
  description: `The Red and Blue Dinosaur Themed Mega Soft Play Package is perfect for toddlers and young children. 
  This package features a 9x11ft dinosaur-themed bouncy castle, foam ball pool, and soft play pieces, ideal for both 
  indoor and outdoor events. Children can engage in imaginative play as little dinosaurs, enjoying hours of entertainment.`,
  safetyHygiene: "Safety and Hygiene are our top priorities at Premium Inflatables! All inflatables, soft play, ball pools, and mats are fully sanitized before every use.",
  additionalCosts: {
    nextMorningCollection: 50
  },
  size: ['9ft , 11.5ft , 8ft', '2.7m , 3.5m , 2.4m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Grass',
    'Outdoor on Hard Surface',
    'Not Suitable for Outdoors on Artificial Grass or Flags'
  ],
  ballPool: {
    description: "Foam ball pool included in the package, suitable for both indoor and outdoor events.",
    size: ['Foam Ball Pool: Red / Blue'],
    suitability: [
      'Indoor on Hard Surface',
      'Outdoor on Grass',
      'Outdoor on Hard Surface'
    ]
  },
  softPlay: {
    description: "Includes 18 pieces of soft play with a 9x matching mat setup, perfect for toddlers and young children.",
    size: ['18pc Soft Play & 9xMega Mat Set'],
    suitability: [
      'Indoor on Hard Surface',
      'Outdoor on Grass',
      'Outdoor on Hard Surface'
    ]
  },
  extras: {
    didiCars: "Optional: 4x Didi Cars & 4x Hoppers available to keep all the little dinosaurs entertained.",
    miniSlide: "Optional: Mini Slide available for added fun.",
    connectFour: "Optional: Giant Connect 4 Game for added fun and competition."
  },
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  dimensions: {
    unitSize: { width: '9ft', length: '11.5ft', height: '8ft' },
    requiredSpace: { width: '12ft', length: '17ft', height: '8.5ft' },
    requiredAccessWidth: '3ft'
  },
  metricDimensions: {
    unitSize: { width: '2.7m', length: '3.5m', height: '2.4m' },
    requiredSpace: { width: '3.7m', length: '5.2m', height: '2.6m' },
    requiredAccessWidth: '0.9m'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  videoLink: "https://youtu.be/i0Eha00_I3U"
}
,

{
  price: 245,
  title: "Dinosaurs Soft Play Bouncy Castle Package - Green / Light Blue",
  img: "/newProducts/dinosaurs-soft-play-bouncy-castle-package-green-light-blue1.png",
  images: [
    "/newProducts/dinosaurs-soft-play-bouncy-castle-package-green-light-blue2.png",
    "/newProducts/dinosaurs-soft-play-slide-bouncy-castle-green-light-blue.png",
    // "/newProducts/DinosaursSoftPlayBouncyCastleGreenBlue2.png"
  ],
  description: `The Green and Light Blue Dinosaur Themed Mega Soft Play Package is perfect for children's parties 
  and events. This package features a 12x15ft dinosaur-themed bouncy castle, foam ball pool, 17 pieces of soft play, 
  and a 9 matching mat set, offering a fun and engaging experience for all the little guests.`,
  safetyHygiene: "All our premium inflatables, soft play, ball pools, balls, and mats come fully sanitized before every use to ensure safety and hygiene.",
  additionalCosts: {
    nextMorningCollection: 50
  },
  size: ['12ft , 15ft , 9.5ft', '3.7m , 4.6m , 2.9m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Grass',
    'Outdoor on Hard Surface',
    'Not Suitable for Outdoors on Artificial Grass or Flags'
  ],
  ballPool: {
    description: "Foam ball pool included in the package, suitable for both indoor and outdoor events.",
    size: ['Foam Ball Pool: Green / Light Blue'],
    suitability: [
      'Indoor on Hard Surface',
      'Outdoor on Grass',
      'Outdoor on Hard Surface'
    ]
  },
  softPlay: {
    description: "Includes 17 pieces of soft play with a 9x matching mat setup, perfect for toddlers and young children.",
    size: ['17pc Soft Play & 9xMega Mat Set'],
    suitability: [
      'Indoor on Hard Surface',
      'Outdoor on Grass',
      'Outdoor on Hard Surface'
    ]
  },
  extras: {
    didiCars: "Optional: Didi Cars & Hoppers available for added fun, safe and easy to use both indoors and outdoors.",
    connectFour: "Optional: Giant Connect 4 Game for added fun and competition."
  },
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  dimensions: {
    unitSize: { width: '12ft', length: '15ft', height: '9.5ft' },
    requiredSpace: { width: '15ft', length: '21ft', height: '10ft' },
    requiredAccessWidth: '3ft'
  },
  metricDimensions: {
    unitSize: { width: '3.7m', length: '4.6m', height: '2.9m' },
    requiredSpace: { width: '4.6m', length: '6.4m', height: '3.0m' },
    requiredAccessWidth: '0.9m'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  videoLink: "https://youtu.be/i0Eha00_I3U"
}
,

{
  price: 245,
  title: "Football Bounce N' Slide Soft Play Package - Red / Blue",
  img: "/newProducts/football-bounce-n-slide-soft-play-package-red-blue.png",
  images: [
    "/newProducts/FootballBounceSlideSoftPlayPackage1.png",
    "/newProducts/FootballBounceSlideSoftPlayPackage2.png"
  ],
  description: `The Football Mega Soft Play Package is a perfect choice for football fans. It includes a 12x16ft 
  red and blue bouncy castle with a slide, a foam ball pool, 17 pieces of matching soft play, and 9 mats to create a fun and exciting 
  party experience. Ideal for both indoor and outdoor events, but soft play and ball pools are restricted to indoor use only.`,
  safetyHygiene: "All inflatables, soft play, ball pools, balls, and mats are fully sanitized for each use, prioritizing safety and hygiene.",
  additionalCosts: {
    nextMorningCollection: 50
  },
  size: ['12ft , 16ft , 9.5ft', '3.7m , 4.9m , 2.9m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Grass',
    'Outdoor on Hard Surface',
    'Not Suitable for Outdoors on Artificial Grass or Flags'
  ],
  ballPool: {
    description: "Foam ball pool included, suitable for indoor use only.",
    size: ['Foam Ball Pool: Red / Blue'],
    suitability: [
      'Indoor on Hard Surface'
    ]
  },
  softPlay: {
    description: "17 pieces of soft play with matching mats, designed for young children.",
    size: ['17pc Soft Play & 9xMega Mat Set'],
    suitability: [
      'Indoor on Hard Surface',
      'Outdoor on Grass',
      'Outdoor on Hard Surface'
    ]
  },
  slide: {
    description: "Football-themed inflatable bouncy castle with slide, perfect for kids' events.",
    size: ['Width: 3.7m, Length: 4.9m, Height: 2.9m'],
    suitability: [
      'Indoor on Hard Surface',
      'Outdoor on Grass',
      'Outdoor on Hard Surface',
      'Not Suitable for Outdoors on Artificial Grass or Flags'
    ]
  },
  extras: {
    didiCars: "Optional: Add Didi Cars and animal hoppers for extra fun. They can be used both inside and outside.",
    connectFour: "Optional: Add a Giant Connect 4 Game."
  },
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  dimensions: {
    unitSize: { width: '12ft', length: '16ft', height: '9.5ft' },
    requiredSpace: { width: '16ft', length: '22ft', height: '10ft' },
    requiredAccessWidth: '3ft'
  },
  metricDimensions: {
    unitSize: { width: '3.7m', length: '4.9m', height: '2.9m' },
    requiredSpace: { width: '4.9m', length: '6.7m', height: '3.0m' },
    requiredAccessWidth: '0.9m'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  videoLink: "https://youtu.be/i0Eha00_I3U"
}
,

{
  price: 245,
  title: "Happy Birthday Soft Play Bouncy Castle Package - Green / Light Blue",
  img: "/newProducts/happy-birthday-soft-play-bouncy-castle-package-red-blue.png",
  images: [
    "/newProducts/happy-birthday-soft-play-bouncy-castle-package-green-light-blue.png",
    // "/newProducts/HappyBirthdayBouncyCastlePackage2.png"
  ],
  description: `Celebrate your special day with the Happy Birthday Soft Play Bouncy Castle Package in vibrant green and light blue. 
  It includes a 15x12ft bouncy castle with slide, a matching foam ball pool, 18 pieces of soft play, and a 9-mat setup. 
  Perfect for children's parties both indoors and outdoors.`,
  safetyHygiene: "All inflatables, soft play, ball pools, balls, and mats are fully sanitized for each use, prioritizing safety and hygiene.",
  size: ['15ft , 12ft , 9.5ft', '4.6m , 3.7m , 2.9m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Grass',
    'Outdoor on Hard Surface',
    'Not Suitable for Outdoors on Artificial Grass or Flags'
  ],
  ballPool: {
    description: "Foam ball pool included, matching the green/light blue theme.",
    size: ['Foam Ball Pool: Green / Light Blue'],
    suitability: [
      'Indoor on Hard Surface'
    ]
  },
  softPlay: {
    description: "18 pieces of soft play with matching mats, ideal for young children.",
    size: ['18pc Soft Play & 9xMega Mat Set'],
    suitability: [
      'Indoor on Hard Surface',
      'Outdoor on Grass',
      'Outdoor on Hard Surface'
    ]
  },
  slide: {
    description: "Birthday-themed inflatable bouncy castle with slide in green and light blue colors, perfect for children's events.",
    size: ['Width: 4.6m, Length: 3.7m, Height: 2.9m'],
    suitability: [
      'Indoor on Hard Surface',
      'Outdoor on Grass',
      'Outdoor on Hard Surface',
      'Not Suitable for Outdoors on Artificial Grass or Flags'
    ]
  },
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  dimensions: {
    unitSize: { width: '15ft', length: '12ft', height: '9.5ft' },
    requiredSpace: { width: '21ft', length: '15ft', height: '10ft' },
    requiredAccessWidth: '3ft'
  },
  metricDimensions: {
    unitSize: { width: '4.6m', length: '3.7m', height: '2.9m' },
    requiredSpace: { width: '6.4m', length: '4.6m', height: '3.0m' },
    requiredAccessWidth: '0.9m'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  videoLink: "https://youtu.be/HappyBirthdayBouncyCastleVideo"
}
,
{
  price: 195,
  title: "Jungle Juniors Slide + Bouncy Castle - Green / Light Blue",
  img: "/newProducts/jungle-juniors-slide-bouncy-castle-green-light-blue1.png",
  images: [
    "/newProducts/jungle-juniors-slide-bouncy-castle-green-light-blue2.png",
    "/newProducts/jungle-soft-play-bouncy-castle-juniors-package-green-light-blue.png"
  ],
  description: `The Jungle Juniors Slide and Bouncy Castle package is an exciting addition to any children's birthday party or event. 
  Featuring vibrant green and light blue colors with jungle-themed artwork, this premium inflatable package includes a bouncy castle 
  and a slide that are perfect for indoor and outdoor settings. Designed with safety and fun in mind, it’s ideal for children under 5.`,
  safetyHygiene: "All inflatables, soft play, ball pools, balls, and mats are fully sanitized for each use, prioritizing safety and hygiene.",
  premiumGuarantees: [
    "New fully sanitized 2024 Premium Inflatables & accessories.",
    "Delivering on time every time.",
    "Punctual collections.",
    "Friendly, polite team dedicated to making your event a success.",
    "24/7 customer service for all inquiries."
  ],
  size: ['9ft , 11ft , 8ft', '2.7m , 3.5m , 2.4m'],
  slideSize: ['12ft , 12ft , 8ft', '3.7m , 3.7m , 2.4m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Artificial Grass',
    'Outdoor on Flags',
    'Outdoor on Grass',
    'Outdoor on Hard Surface',
    'Not Suitable for Outdoors on Artificial Grass or Flags'
  ],
  bouncyCastle: {
    description: "Jungle-themed bouncy castle, ideal for low-ceiling venues.",
    size: { width: '9ft', length: '11ft', height: '8ft' },
    requiredSpace: { width: '12ft', length: '17ft', height: '8.5ft' },
    metricSize: { width: '2.7m', length: '3.5m', height: '2.4m' },
    metricRequiredSpace: { width: '3.7m', length: '5.2m', height: '2.6m' }
  },
  juniorsSlide: {
    description: "Juniors inflatable slide designed for safe play.",
    size: { width: '12ft', length: '12ft', height: '8ft' },
    slidePlatformHeight: '5ft',
    requiredSpace: { width: '3.7m', length: '3.7m', height: '2.4m' }
  },
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  videoLink: "https://youtu.be/JungleJuniorsSlideBouncyCastleVideo",
  nextMorningCollectionFee: 50
}
,

{
  price: 195,
  title: "Jungle Soft Play Bouncy Castle Juniors Package - Green / Light Blue",
  img: "/newProducts/jungle-soft-play-bouncy-castle-juniors-package-green-light-blue1.png",
  images: [
    "/newProducts/jungle-soft-play-bouncy-castle-juniors-package-green-light-blue2.png",
    "/newProducts/jungle-soft-play-bouncy-castle-juniors-package-green-light-blue3.png",
    // "/newProducts/juniors-slide-bouncy-castle-green-light-blue.png",

  ],
  description: `The Jungle themed Mega Soft Play Under 5's Package is an amazing addition to any birthday party or event, 
  boasting the classic cartoon jungle artwork which is finished in a modern gloss to match the premium gloss finish on all our inflatables. 
  The Toddlers Jungle Bouncy Castle is perfect for low ceiling indoor venues, paired with a matching luxury foam ball pool and 
  soft play pieces for endless fun!`,
  safetyHygiene: "Safety and hygiene are our paramount priorities! All our Premium inflatables, Soft Play, Ball Pools, Balls, and Mats come fully sanitized for every use.",
  premiumGuarantees: [
    "New fully sanitized 2024 Premium Inflatables & accessories.",
    "Delivering on time every time.",
    "Punctual collections.",
    "Friendly, polite team dedicated to making your event a success.",
    "24/7 customer service for all inquiries."
  ],
  size: ['9ft , 11ft , 8ft', '2.7m , 3.5m , 2.4m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Artificial Grass',
    'Outdoor on Flags',
    'Outdoor on Grass',
    'Outdoor on Hard Surface'
  ],
  bouncyCastle: {
    description: "Jungle-themed bouncy castle, ideal for low-ceiling venues.",
    size: { width: '9ft', length: '11ft', height: '8ft' },
    requiredSpace: { width: '12ft', length: '17ft', height: '8.5ft' },
    metricSize: { width: '2.7m', length: '3.5m', height: '2.4m' },
    metricRequiredSpace: { width: '3.7m', length: '5.2m', height: '2.6m' }
  },
  users: [
    'Suitable for Children under 5',
    'Not Suitable for Adults'
  ],
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  videoLink: "https://youtu.be/JungleSoftPlayBouncyCastle",
  nextMorningCollectionFee: 50,
  extras: [
    "Didi Cars and Hoppers",
    "Giant Connect 4 Game"
  ]
}
,

{
  price: 195,
  title: "Juniors Slide + Bouncy Castle - Green / Light Blue",
  img: "/newProducts/juniors-slide-bouncy-castle-green-light-blue.png",
  images: [
    "/newProducts/juniors-slide-bouncy-castle-pink-purple.png",
    "/newProducts/juniors-slide-bouncy-castle-red-blue.png",
    // "/newProducts/jungle-soft-play-bouncy-castle-juniors-package-green-light-blue.png",
  ],
  description: `Premium Inflatables your local bouncy castle hire near you. Number #1 Google 
  Review Rated Bouncy Castle Hirer for Leeds and Wakefield and surroundings. Delivering you a choice of UK's latest most on trend new purchases and additions 
  to our outstanding Premium 2024 Fleet!! Never to be mistaken with lesser lower services offering low quality older cheap bouncy castles for hire!!
  
  The Plain No Theme Bouncy Castle in Green / Light blue paired with matching Green / Light blue Slide is an amazing 
  addition to any children's birthday party or event, boasting the classic plain no theme colour way which is finished 
  in a modern gloss to match the premium gloss finish on all our inflatables. The Plain no Themed bouncy castle and slide package is Ideal for all your indoor and outdoor events and special occasions. 
  This package can be easily upgraded and paired with ball pools, soft play and matching mat set up to make an incredible package.`,
  safetyHygiene: "Safety and Hygiene are the Paramount Priority here at Premium Inflatables!! All our Premium inflatables, Soft Play, Ball Pools, Balls, Mats come fully sanitised for every use.",
  premiumGuarantees: [
    "New fully sanitized 2024 Premium Inflatables & accessories.",
    "Delivering on time every time.",
    "Punctual collections.",
    "Friendly, polite team dedicated to making your event a success.",
    "24/7 customer service for all inquiries."
  ],
  size: ['12ft , 12ft , 8ft', '3.7m , 3.7m , 2.4m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Artificial Grass',
    'Outdoor on Flags',
    'Outdoor on Grass',
    'Outdoor on Hard Surface'
  ],
  bouncyCastle: {
    description: "Plain No Theme Bouncy Castle in Green/Light Blue paired with matching slide, ideal for all events.",
    size: { width: '9ft', length: '11ft', height: '8ft' },
    requiredSpace: { width: '12ft', length: '17ft', height: '8.5ft' },
    metricSize: { width: '2.7m', length: '3.5m', height: '2.4m' },
    metricRequiredSpace: { width: '3.7m', length: '5.2m', height: '2.6m' }
  },
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  videoLink: "https://youtu.be/JuniorsSlideBouncyCastle",
  nextMorningCollectionFee: 50,
  extras: [
    "Didi Cars and Hoppers",
    "Giant Connect 4 Game"
  ]
}
,

{
  price: 245,
  title: "Mega Pack Soft Play with Air Juggler & Large Castle - Jungle Green / Light Blue",
  img: "/newProducts/mega-pack-soft-play-with-air-juggler-and-large-castle-jungle-green-light-blue.png",
  images: [
    "/newProducts/mega-pack-soft-play-with-air-juggler-and-large-castle-jungle-green-light-blue1.png",
    "/newProducts/mega-pack-soft-play-with-air-juggler-and-large-castle-jungle-green-light-blue2.png",
    "/newProducts/mega-pack-soft-play-with-air-juggler-and-large-castle-jungle-green-light-blue3.png",
    "/newProducts/mega-pack-soft-play-with-air-juggler-and-large-castle-jungle-green-light-blue4.png",
    "/newProducts/mega-pack-soft-play-with-air-juggler-and-large-castle-jungle-green-light-blue5.png",
    "/newProducts/mega-pack-soft-play-with-air-juggler-and-large-castle-jungle-green-light-blue6.png",
    "/newProducts/mega-pack-soft-play-with-air-juggler-and-large-castle-jungle-green-light-blue7.png",
    "/newProducts/mega-pack-soft-play-with-air-juggler-and-large-castle-jungle-green-light-blue8.png",
    "/newProducts/mega-pack-soft-play-with-air-juggler-and-large-castle-jungle-green-light-blue9.png",

    // "/newProducts/mega-pack-soft-play-jungle-package.png",
  ],
  description: `Premium Inflatables your local bouncy castle hire near you. Number #1 Google Review 
  Rated Bouncy Castle Hirer for Leeds and Wakefield and surroundings. Delivering you a choice of UK's latest most on trend new purchases and additions 
  to our outstanding Premium 2024 Fleet!! Never to be mistaken with lesser lower services offering low quality older cheap bouncy castles for hire!!
  
  We’ve carefully selected our Green & Light Blue Jungle Mega Pack, putting together our highly demanded 12ft x 15ft Jungle 
  bouncy castle which measures 9.5ft in height perfect fit for all your indoor hires, coupled with the floating ball feature 
  on our matching air juggler Jungle ball pool keeping the under 5’s & toddlers entertained every time, not forgetting our 17pc 
  matching Jungle Soft Play set + matching Green / Light Blue Mega Mat set completing your Green Jungle Mega Package fit for your 
  Jungle themed Birthday Party Celebrations.`,
  safetyHygiene: "Safety and Hygiene are the Paramount Priority here at Premium Inflatables!! All our Premium inflatables, Soft Play, Ball Pools, Balls, Mats come fully sanitised for every use.",
  premiumGuarantees: [
    "New fully sanitized 2024 Premium Inflatables & accessories.",
    "Delivering on time every time.",
    "Punctual collections.",
    "Friendly, polite team dedicated to making your event a success.",
    "24/7 customer service for all inquiries."
  ],
  size: ['12ft , 15ft , 9.5ft', '3.7m , 4.6m , 2.9m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Artificial Grass',
    'Outdoor on Flags',
    'Outdoor on Grass',
    'Outdoor on Hard Surface'
  ],
  bouncyCastle: {
    description: "12ft x 15ft Jungle Bouncy Castle with Air Juggler Matching Jungle Ball Pool and 17pc Soft Play set.",
    size: { width: '12ft', length: '15ft', height: '9.5ft' },
    requiredSpace: { width: '15ft', length: '21ft', height: '10ft' },
    metricSize: { width: '3.7m', length: '4.6m', height: '2.9m' },
    metricRequiredSpace: { width: '4.6m', length: '6.4m', height: '3.0m' }
  },
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  videoLink: "https://youtu.be/EFeBLmetHes",
  extras: [
    "Didi Wiggle Cars & Hoppers",
    "Giant Connect 4 Game"
  ]
}
,

{
  price: 195,
  title: "Mermaids Juniors Slide + Bouncy Castle - Pink / Purple",
  img: "/newProducts/mermaids-juniors-slide-bouncy-castle-pink-purple.png",
  images: [
    "/newProducts/mermaids-juniors-slide-bouncy-castle-pink-purple1.png",
    "/newProducts/mermaids-soft-play-slide-bouncy-castle-pink-purple.png",
    // "/newProducts/mermaids-juniors-slide-bouncy-castle-package.png",
  ],
  description: `Perfect for any mermaid-themed event, our Mermaids Juniors Slide and Bouncy Castle package 
  combines fun and excitement in beautiful pink and purple colors. This inflatable duo will keep the kids entertained 
  for hours and make their special day unforgettable!`,
  size: [
    { unit: "Juniors Inflatable Bouncy Slide", dimensions: '12ft x 12ft x 8ft', requiredSpace: '15ft x 17ft x 9ft', slidePlatformHeight: '5ft' },
    { unit: "Juniors Inflatable Bouncy Slide (metric)", dimensions: '3.7m x 3.7m x 2.4m', requiredSpace: '4.6m x 5.2m x 2.7m', slidePlatformHeight: '1.5m' },
    { unit: "Mermaids Bouncy Castle", dimensions: '9.0ft x 11.5ft x 8.0ft', requiredSpace: '12.0ft x 17.0ft x 8.5ft' },
    { unit: "Mermaids Bouncy Castle (metric)", dimensions: '2.7m x 3.5m x 2.4m', requiredSpace: '3.7m x 5.2m x 2.6m' }
  ],
  suitability: [
    { unit: "Juniors Inflatable Bouncy Slide", suitableFor: ['Children'], notSuitableFor: ['Adults'], locations: ['Indoor on Hard Surface', 'Outdoor on Grass', 'Outdoor on Hard Surface'] },
    { unit: "Mermaids Bouncy Castle", suitableFor: ['Children'], notSuitableFor: ['Adults'], locations: ['Indoor on Hard Surface', 'Outdoor on Grass', 'Outdoor on Hard Surface'] }
  ]
},
{
  price: 195,
  title: "Party Time Bouncy Castle & Matching Inflatable Ball Pool",
  img: "/newProducts/party-time-bounce-n-slide-soft-play-package-red-blue.png",
  images: [
    "/newProducts/party-time-bounce-n-slide-soft-play-package-red-blue1.png",
    "/newProducts/party-time-bounce-n-slide-soft-play-package-red-blue2.png",
    "/newProducts/party-time-bounce-n-slide-soft-play-package-red-blue3.png",
    "/newProducts/party-time-bounce-n-slide-soft-play-package-red-blue4.png",
    "/newProducts/party-time-bounce-n-slide-soft-play-package-red-blue5.png",
  
  ],
  description: `The Party Time Themed bouncy castle and inflatable ball pool is an amazing addition to any birthday party or event, boasting the classic cartoon party time artwork which is finished in a modern gloss to match the premium gloss finish on all our inflatables. If this amazing inflatable wasn't already good enough, why not take your special event to the next level by adding our Premium Entertainment Experience—the ultimate bouncy castle upgrade to include disco lights & a big Bluetooth speaker. The Party Time Themed bouncy castle is ideal for all your indoor and outdoor events and special occasions. This castle can be easily paired with slides, soft play, and a matching mat setup to make an incredible package.`,
  safetyHygiene: "Safety and Hygiene are the Paramount Priority here at Premium Inflatables!! All our Premium inflatables come fully sanitised for every use.",
  premiumGuarantees: [
    "New fully sanitized Premium Inflatables & accessories.",
    "Delivering on time every time.",
    "Punctual collections.",
    "Friendly, polite team dedicated to making your event a success.",
    "24/7 customer service for all inquiries."
  ],
  size: ['12ft', '15ft', '9.5ft', '3.7m', '4.6m', '2.9m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Grass',
    'Outdoor on Hard Surface',
    'Outdoor on Artificial Grass',
    'Outdoor on Flags'
  ],
  bouncyCastle: {
    description: "12ft x 15ft Party Time Printed Bouncy Castle with matching inflatable ball pool.",
    size: { width: '12ft', length: '15ft', height: '9.5ft' },
    requiredSpace: { width: '15ft', length: '21ft', height: '10ft' },
    metricSize: { width: '3.7m', length: '4.6m', height: '2.9m' },
    metricRequiredSpace: { width: '4.6m', length: '6.4m', height: '3.0m' }
  },
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  videoLink: "https://youtu.be/EFeBLmetHes",
  extras: [
    "Slides",
    "Soft Play",
    "Matching Mat Set"
  ]
}
,

{
  price: 195,
  title: "Party Time Juniors Slide + Bouncy Castle - Green / Light Blue",
  nextMorningCollection: 50,
  img: "/newProducts/party-time-juniors-slide-bouncy-castle-green-light-blue1.png",
  images: [
    "/newProducts/party-time-juniors-slide-bouncy-castle-pink-purple.png",
   
  ],
  description: `Premium Inflatables your local bouncy castle hire near you. Number #1 Google Review Rated Bouncy Castle Hirer for Leeds and Wakefield and surroundings. Delivering you a choice of UK's latest most on trend new purchases and additions to our outstanding Premium 2024 Fleet!! Never to be mistaken with lesser lower services offering low quality older cheap bouncy castles for hire!!`,
  safetyHygiene: "Safety and Hygiene are the Paramount Priority here at Premium Inflatables!! All our Premium inflatables, Soft Play, Ball Pools, Balls, Mats come fully sanitised for every use.",
  whyChooseUs: `Why Choose Premium Inflatables Bouncy Castle Hire Wakefield? CLICK HERE TO SEE OUR GOOGLE CLIENT REVIEWS FEEDBACK. Have our trained team deliver and setup this inflatable at your chosen home or venue.`,
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse',
    'Rothwell', 'Methley', 'Normanton', 'Featherstone',
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington',
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  dimensions: {
    unitSize: {
      imperial: { width: '12ft', length: '12ft', height: '8ft' },
      metric: { width: '3.7m', length: '3.7m', height: '2.4m' },
      slidePlatformHeight: { imperial: '5ft', metric: '1.5m' }
    },
    requiredSpace: {
      imperial: { width: '12.0ft', length: '17.0ft', height: '8.5ft' },
      metric: { width: '3.7m', length: '5.2m', height: '2.6m' }
    }
  },
  suitability: [ 
   
      'Indoors on Hard Surface'
    ,
  
      'Outdoors on Grass',
      'Outdoors on Hard Surface',
      'Outdoors on Artificial Grass',
      'Outdoors on Flags'
    ]
,
  extras: [
    "Slides",
    "Soft Play",
    "Matching Mat Set"
  ]
}


,

{
  price: 195,
  title: "Party Time Soft Play Bouncy Castle Juniors Package - Pink / Purple",
  img: "/newProducts/party-time-soft-play-bouncy-castle-juniors-package-red-blue.png",
  images: [
    "/newProducts/party-time-soft-play-bouncy-castle-juniors-package-pink-purple1.png",
    "/newProducts/party-time-soft-play-bouncy-castle-juniors-package-pink-purple2.png",
    "/newProducts/party-time-soft-play-bouncy-castle-juniors-package-pink-purple3.png",

 
  ],
  description: `The Party Time Themed Mega Soft Play Package features a 9ft, 11ft bouncy castle perfect for indoor and outdoor events, with the classic cartoon Party Time artwork in a modern gloss finish. This package also includes a foam ball pool and matching soft play set to ensure endless fun for your little ones.`,
  safetyHygiene: "Safety and Hygiene are the Paramount Priority at Premium Inflatables! All inflatables, soft play, ball pools, balls, and mats are fully sanitized before every use.",
  additionalCosts: {
    nextMorningCollection: 0 // Optional costs can be added if applicable
  },
  size: ['9ft, 11ft, 8ft', '2.7m, 3.5m, 2.4m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Grass',
    'Outdoor on Hard Surface'
  ],
  additionalInformation: `Consider adding our package of Didi Cars and Hoppers for safe, fun, and easy entertainment. For inquiries, call 0113 460 1386 or email info@premiuminflatables.co.uk. Book online using the 'Check Availability' and 'Book Online' buttons.`,
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  dimensions: {
    unitSize: { width: '9ft', length: '11ft', height: '8ft' },
    requiredSpace: { width: '12ft', length: '17ft', height: '8.5ft' },
    requiredAccessWidth: '3ft'
  },
  metricDimensions: {
    unitSize: { width: '2.7m', length: '3.5m', height: '2.4m' },
    requiredSpace: { width: '3.7m', length: '5.2m', height: '2.6m' },
    requiredAccessWidth: '0.9m'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ]
}

,

{
  price: 245,
  title: "Party Time Soft Play Bouncy Castle Package - Green / Light Blue",
  img: "/newProducts/party-time-soft-play-bouncy-castle-package-red-blue.png",
  images: [
    "/newProducts/party-time-soft-play-bouncy-castle-package-red-blue1.png",
    "/newProducts/party-time-soft-play-bouncy-castle-package-red-blue2.png",
 
  ],
  description: `The Party Time Themed Mega Soft Play Package features a 12ft, 15ft bouncy castle, perfect for indoor and outdoor events. This package also includes a foam ball pool and matching soft play set, designed to keep children entertained with its bright colors and fun design.`,
  safetyHygiene: "Safety and Hygiene are the Paramount Priority at Premium Inflatables! All inflatables, soft play, ball pools, balls, and mats are fully sanitized before every use.",
  additionalCosts: {
    nextMorningCollection: 0 // Optional costs can be added if applicable
  },
  size: ['12ft, 15ft, 9.5ft', '3.7m, 4.6m, 2.9m'],
  suitability: [
    'Indoor on Hard Surface',
    'Outdoor on Grass',
    'Outdoor on Hard Surface'
  ],
  additionalInformation: `Add optional extras like a ball pool and soft play sets to enhance your party experience. For inquiries, call 0113 460 1386 or email info@premiuminflatables.co.uk. Book online using the 'Check Availability' and 'Book Online' buttons.`,
  users: [
    'Suitable for Children',
    'Not Suitable for Adults'
  ],
  dimensions: {
    unitSize: { width: '12ft', length: '15ft', height: '9.5ft' },
    requiredSpace: { width: '15ft', length: '21ft', height: '10ft' },
    requiredAccessWidth: '3ft'
  },
  metricDimensions: {
    unitSize: { width: '3.7m', length: '4.6m', height: '2.9m' },
    requiredSpace: { width: '4.6m', length: '6.4m', height: '3.0m' },
    requiredAccessWidth: '0.9m'
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse', 
    'Rothwell', 'Methley', 'Normanton', 'Featherstone', 
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington', 
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ]
}
,

{
  price: 245,
  title: "Peppa Pig Soft Play & Bouncy Castle Package",
  nextMorningCollection: 50,
  img: "/newProducts/peppa-pig-soft-play-and-bouncy-castle-package.png",
  images: [
    "/newProducts/peppa-pig-soft-play-and-bouncy-castle-package1.png",
    "/newProducts/peppa-pig-soft-play-and-bouncy-castle-package2.png",
    "/newProducts/peppa-pig-soft-play-and-bouncy-castle-package3.png",
    "/newProducts/peppa-pig-soft-play-and-bouncy-castle-package4.png",
    "/newProducts/peppa-pig-soft-play-and-bouncy-castle-package5.png",

    
  ],
  description: `Premium Inflatables your local bouncy castle hire near you. Number #1 Google Review Rated Bouncy Castle Hirer for Leeds and Wakefield and surroundings. Delivering you a choice of UK's latest most on trend new purchases and additions to our outstanding Premium 2024 Fleet!! Never to be mistaken with lesser lower services offering low quality older cheap bouncy castles for hire!!`,
  safetyHygiene: "Safety and Hygiene are the Paramount Priority here at Premium Inflatables!! All our Premium inflatables, Soft Play, Ball Pools, Balls, Mats come fully sanitised for every use.",
  whyChooseUs: `Why Choose Premium Inflatables Bouncy Castle Hire Wakefield? CLICK HERE TO SEE OUR GOOGLE CLIENT REVIEWS FEEDBACK. Have our trained team deliver and setup this inflatable at your chosen home or venue.`,
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse',
    'Rothwell', 'Methley', 'Normanton', 'Featherstone',
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington',
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  size:['12ft,12ft,9.5ft','3.7m,3.7m,2.9m'],

    requiredSpace: {
      imperial: { width: '15ft', length: '19ft' },
      metric: { width: '4.6m', length: '5.8m' }
    },
    requiredAccessWidth: {
      imperial: '3ft',
      metric: '0.9m'
    },
  
  suitability: [ 
    'Indoors on Hard Surface',
    'Outdoors on Grass',
    'Outdoors on Hard Surface'
  ],
  extras: [
    "Didi Cars",
    "Hoppers",
    "Matching Pink Soft Play (17pc) + Mega Mat",
    "Pink Ball Pool + Matching Pink/Purple Commercial Balls"
  ]
}
,
{
  price: 155,
  title: "Premium Jungle Soft Play with Air Juggler Ball Pool - Green / Light Blue",
  nextMorningCollection: 50,
  img: "/newProducts/premium-jungle-soft-play-with-air-juggler-ball-pool-green-light-blue.png",
  images: [
    "/newProducts/premium-jungle-soft-play-with-air-juggler-ball-pool-green-light-blue.png",
  
  ],
  description: `Premium Inflatables your number #1 Google Review Rated bouncy castle hirer brings you one of our new purchases and additions to our outstanding premium 2024 fleet!! We’ve carefully selected our Premium Jungle Package perfect fit for all your indoor hires, coupled with the floating ball feature on our matching air juggler ball pool keeping the under 5’s & toddlers entertained every time, not forgetting our 16pc matching Jungle Soft Play set + matching Green/Blue Mega Mat set completing your Premium Jungle Package fit for your little Monkeys Birthday Party Celebration.`,
  safetyHygiene: "We do not hire our soft play & foam ball pools for outdoor use. Please make enquiries for alternatives on our Contact Page. All our inflatables and equipment are fully sanitised for every use.",
  whyChooseUs: `Why Choose Premium Inflatables Bouncy Castle Hire Wakefield? CLICK HERE TO SEE OUR GOOGLE CLIENT REVIEWS FEEDBACK. Have our trained team deliver and setup this inflatable at your chosen home or venue.`,
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse',
    'Rothwell', 'Methley', 'Normanton', 'Featherstone',
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington',
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  dimensions: {
    unitSize: {
      imperial: { width: 'N/A', length: 'N/A', height: 'N/A' },
      metric: { width: 'N/A', length: 'N/A', height: 'N/A' }
    },
    requiredSpace: {
      imperial: { width: 'N/A', length: 'N/A' },
      metric: { width: 'N/A', length: 'N/A' }
    }
  },
  suitability: [ 
    'Indoors on Hard Surface',
    'Outdoors on Grass',
    'Outdoors on Artificial Grass',
    'Outdoors on Flags',
    'Outdoors on Hard Surface'
  ],
  extras: [
    "Air Juggler Matching Ball Pool",
    "16pc Jungle Soft Play Set",
    "Matching Green/Blue Mega Mat",
    "Didi Wiggle Cars",
    "Hoppers"
  ]
}
,
{
  price: 245,
  title: "Princess Bounce N' Slide Soft Play Package - Pink / Purple",
  img: "/newProducts/princess-juniors-slide-bouncy-castle-pink-purple.png",
  images: [
    "/newProducts/princess-bounce-n-slide-soft-play-package-pink-purple1.png",
    "/newProducts/princess-bounce-n-slide-soft-play-package-pink-purple2.png",
    "/newProducts/princess-bounce-n-slide-soft-play-package-pink-purple3.png",
    "/newProducts/princess-bounce-n-slide-soft-play-package-pink-purple4.png",
    "/newProducts/princess-bounce-n-slide-soft-play-package-pink-purple5.png",
    "/newProducts/princess-bounce-n-slide-soft-play-package-pink-purple6.png",
    "/newProducts/princess-bounce-n-slide-soft-play-package-pink-purple7.png",
    "/newProducts/princess-bounce-n-slide-soft-play-package-pink-purple8.png",
   
  ],
  description: `Premium Inflatables your local bouncy castle hire near you. Number #1 Google Review Rated Bouncy Castle Hirer for Leeds and Wakefield and surroundings. The Princess Themed Mega Soft Play Package is an amazing set up! It will keep all your Princesses entertained throughout the day! Its Pink/Purple colours are a fabulous addition to your birthday celebrations. The Princess Themed bouncy castle with Slide 12x16ft is perfect for all your indoor and outdoor events and special occasions. This castle is paired with a foam ball pool, 17 pieces of soft play and matching 9 Mega mat set up to make an incredible package.`,
  safetyHygiene: "We ensure all our inflatables are fully sanitized before every use. Please note that soft play & foam ball pools are not hired for outdoor use. For alternatives, please contact us.",
  whyChooseUs: `Why Choose Premium Inflatables Bouncy Castle Hire Leeds and Wakefield? CLICK HERE TO SEE OUR GOOGLE CLIENT REVIEWS FEEDBACK. Our trained team will deliver and set up the inflatables at your chosen venue.`,
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse',
    'Rothwell', 'Methley', 'Normanton', 'Featherstone',
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington',
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  // dimensions: {
  //   unitSize: {
  //     imperial: { width: '12ft', length: '16ft', height: '9.5ft' },
  //     metric: { width: '3.7m', length: '4.9m', height: '2.9m' }
  //   },
  size :['12ft,16ft,9.5ft','3.7m,4.9m,2.9m'],
    requiredSpace: {
      imperial: { width: '16ft', length: '22ft', height: '10ft' },
      metric: { width: '4.9m', length: '6.7m', height: '3.0m' }
    },
    requiredAccessWidth: {
      imperial: '3ft',
      metric: '0.9m'
    },

  suitability: [
    'Indoors on Hard Surface',
    'Outdoors on Grass',
    'Outdoors on Artificial Grass',
    'Outdoors on Flags',
    'Outdoors on Hard Surface'
  ],
  castleSuitability: {
    for: 'Children',
    notFor: 'Adults',
    limitations: [
      'Not suitable outdoors on Artificial Grass',
      'Not suitable outdoors on Flags'
    ]
  },
  extras: [
    "Foam Ball Pool - Pink/Purple",
    "17pc Matching Soft Play",
    "9pc Mega Mat",
    "Didi Cars",
    "Hoppers"
  ]
}
,
{
  price: 195,
  title: "Princess Juniors Slide + Bouncy Castle - Pink / Purple",
  img: "/newProducts/princess-soft-play-slide-bouncy-castle-pink-purple.png",
  images: [
  "/newProducts/princess-soft-play-bouncy-castle-package-pink-purple1.png",
  "/newProducts/princess-soft-play-bouncy-castle-package-pink-purple2.png",
  "/newProducts/princess-soft-play-bouncy-castle-package-pink-purple3.png",
  "/newProducts/princess-soft-play-bouncy-castle-package-pink-purple4.png",
  "/newProducts/princess-soft-play-bouncy-castle-package-pink-purple5.png",
  "/newProducts/princess-soft-play-bouncy-castle-package-pink-purple6.png",
  "/newProducts/princess-soft-play-bouncy-castle-package-pink-purple7.png",
  "/newProducts/princess-soft-play-bouncy-castle-package-pink-purple8.png",

  ],
  description: `Premium Inflatables your local bouncy castle hire near you. Number #1 Google Review Rated Bouncy Castle Hirer for Leeds and Wakefield and surroundings. The Princess Themed bouncy castle paired with matching Pink & Purple slide is an amazing addition to any children's birthday party or event, boasting the classic Princess artwork with a modern gloss finish. The package is perfect for all indoor and outdoor events and can be upgraded with ball pools, soft play, and matching mat set up.`,
  safetyHygiene: "All inflatables, soft play, ball pools, balls, and mats are fully sanitized before every use to ensure the highest level of safety and hygiene.",
  whyChooseUs: `Why Choose Premium Inflatables Bouncy Castle Hire Leeds and Wakefield? CLICK HERE TO SEE OUR GOOGLE CLIENT REVIEWS FEEDBACK. Our trained team will deliver and set up the inflatables at your chosen venue.`,
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse',
    'Rothwell', 'Methley', 'Normanton', 'Featherstone',
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington',
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  size:['12ft,12ft,8ft','3.7m,3.7m,2.7m'],
  dimensions: {
    juniorSlide: {
      imperial: { width: '12ft', length: '12ft', height: '8ft', platformHeight: '5ft' },
      metric: { width: '3.7m', length: '3.7m', height: '2.4m', platformHeight: '1.5m' },
      requiredSpace: {
        imperial: { width: '15ft', length: '17ft', height: '9ft' },
        metric: { width: '4.6m', length: '5.2m', height: '2.7m' }
      }
    },
    bouncyCastle: {
      imperial: { width: '9ft', length: '11.5ft', height: '8ft' },
      metric: { width: '2.7m', length: '3.5m', height: '2.4m' },
      requiredSpace: {
        imperial: { width: '12ft', length: '17ft', height: '8.5ft' },
        metric: { width: '3.7m', length: '5.2m', height: '2.6m' }
      }
    }
  },
  suitability: [
    'Indoors on Hard Surface',
    'Outdoors on Grass',
    'Outdoors on Artificial Grass',
    'Outdoors on Flags',
    'Outdoors on Hard Surface'
  ],
  slideSuitability: {
    for: 'Children',
    notFor: 'Adults',
    limitations: [
      'Not suitable outdoors on Artificial Grass',
      'Not suitable outdoors on Flags'
    ]
  },
  castleSuitability: {
    for: 'Children',
    notFor: 'Adults',
    limitations: [
      'Not suitable outdoors on Artificial Grass',
      'Not suitable outdoors on Flags'
    ]
  },
  extras: [
    "Foam Ball Pool",
    "Soft Play",
    "Matching Mats",
    "Didi Cars",
    "Hoppers"
  ]
}
,

{
  price: 295,
  title: "Princess Soft Play + Slide + Bouncy Castle - Pink / Purple",
  img: "/newProducts/princess-soft-play-slide-bouncy-castle-pink-purple.png",
  images: [
    "/newProducts/princess-soft-play-slide-bouncy-castle-pink-purple.png",
  ],
  description: `Premium Inflatables brings you the Princess Themed Super Size Soft Play package with a mini platform slide, foam ball pool, soft play setup, and matching 9-mat layout, ideal for all your indoor and outdoor events. This premium package is perfect for celebrating your little princess’s birthday or any special occasion.`,
  safetyHygiene: "All inflatables, soft play, ball pools, and mats are fully sanitized for every hire to ensure the highest level of safety and hygiene.",
  whyChooseUs: `Why Choose Premium Inflatables Bouncy Castle Hire Leeds and Wakefield? CLICK HERE TO SEE OUR GOOGLE CLIENT REVIEWS FEEDBACK. Our trained team will deliver and set up this package at your chosen venue.`,
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse',
    'Rothwell', 'Methley', 'Normanton', 'Featherstone',
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington',
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  dimensions: {
    juniorSlide: {
      imperial: { width: '12ft', length: '12ft', height: '8ft', platformHeight: '5ft' },
      metric: { width: '3.7m', length: '3.7m', height: '2.4m', platformHeight: '1.5m' },
      requiredSpace: {
        imperial: { width: '15ft', length: '17ft', height: '9ft' },
        metric: { width: '4.6m', length: '5.2m', height: '2.7m' }
      }
    },
    bouncyCastle: {
      imperial: { width: '9ft', length: '11.5ft', height: '8ft' },
      metric: { width: '2.7m', length: '3.5m', height: '2.4m' },
      requiredSpace: {
        imperial: { width: '12ft', length: '17ft', height: '8.5ft' },
        metric: { width: '3.7m', length: '5.2m', height: '2.6m' }
      }
    },
    foamBallPool: {
      suitableFor: ['Indoor Indoors on Hard Surface', 'Outdoor Outdoors on Artificial Grass', 'Outdoor Outdoors on Flags', 'Outdoor Outdoors on Grass', 'Outdoor Outdoors on Hard Surface']
    },
    softPlaySetup: {
      description: "Soft Play 18pc & 9xMega Mat Set Up",
      suitableFor: ['Indoor Indoors on Hard Surface', 'Outdoor Outdoors on Artificial Grass', 'Outdoor Outdoors on Flags', 'Outdoor Outdoors on Grass', 'Outdoor Outdoors on Hard Surface']
    }
  },
  size:['12ft,12ft,8ft','3.7m,3.7m,2.4mx1.5m,'],
  suitability: [
    'Indoors on Hard Surface',
    'Outdoors on Grass',
    'Outdoors on Artificial Grass',
    'Outdoors on Flags',
    'Outdoors on Hard Surface'
  ],
  slideSuitability: {
    for: 'Children',
    notFor: 'Adults',
    limitations: [
      'Not suitable outdoors on Artificial Grass',
      'Not suitable outdoors on Flags'
    ]
  },
  castleSuitability: {
    for: 'Children',
    notFor: 'Adults',
    limitations: [
      'Not suitable outdoors on Artificial Grass',
      'Not suitable outdoors on Flags'
    ]
  },
  extras: [
    "Didi Cars",
    "Hoppers"
  ]
}
,

{
  price: 195,
  nextMorningCollection: 50,
  title: "Sea World Juniors Slide + Bouncy Castle - Green / Light Blue",
  img: "/newProducts/sea-world-juniors-slide-bouncy-castle-green-light-blue.png",
  images: [
    "/newProducts/sea-world-juniors-slide-bouncy-castle-green-light-blue.png",
  ],
  description: `Premium Inflatables presents the Sea World Bouncy Castle with a mini slide in Green & Light Blue, perfect for kids' parties and events. This inflatable is ideal for both indoor and outdoor setups and is part of our Premium 2024 Fleet, ensuring the latest trends and high-quality materials.`,
  safetyHygiene: "Safety and Hygiene are paramount. All inflatables, soft play items, ball pools, mats, and equipment are fully sanitized before each hire for your peace of mind.",
  whyChooseUs: `Why Choose Premium Inflatables Bouncy Castle Hire Wakefield? CLICK HERE TO SEE OUR GOOGLE CLIENT REVIEWS FEEDBACK. Our experienced team will deliver and set up at your preferred venue, ensuring a smooth and safe experience.`,
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse',
    'Rothwell', 'Methley', 'Normanton', 'Featherstone',
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington',
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  dimensions: {
    juniorSlide: {
      imperial: { width: '12ft', length: '12ft', height: '8ft', platformHeight: '5ft' },
      metric: { width: '3.7m', length: '3.7m', height: '2.4m', platformHeight: '1.5m' }
    },
    bouncyCastle: {
      imperial: { width: '9ft', length: '11.5ft', height: '8ft' },
      metric: { width: '2.7m', length: '3.5m', height: '2.4m' },
      requiredSpace: {
        imperial: { width: '12ft', length: '17ft', height: '8.5ft' },
        metric: { width: '3.7m', length: '5.2m', height: '2.6m' }
      }
    }
  },
  // size:['9ft,11ft,8ft']
  suitability: [
    'Indoors on Hard Surface',
    'Outdoors on Grass',
    'Outdoors on Artificial Grass',
    'Outdoors on Flags',
    'Outdoors on Hard Surface'
  ],
  slideSuitability: {
    for: 'Children',
    notFor: 'Adults',
    limitations: [
      'Not suitable outdoors on Artificial Grass',
      'Not suitable outdoors on Flags'
    ]
  },
  castleSuitability: {
    for: 'Children',
    notFor: 'Adults',
    limitations: [
      'Not suitable outdoors on Artificial Grass',
      'Not suitable outdoors on Flags'
    ]
  }
}
,

{
  price: 195,
  nextMorningCollection: 50,
  title: "Soft Play Bouncy Castle Juniors Package - Green / Light Blue",
  img: "/newProducts/soft-play-bouncy-castle-juniors-package-green-light-blue.png",
  images: [
  "/newProducts/soft-play-bouncy-castle-juniors-package-green-light-blue.png",
  ],
  description: `Premium Inflatables presents the Soft Play Bouncy Castle Juniors Package in Green & Light Blue. This inflatable package is designed for toddlers and young children, providing a safe and fun environment. The setup includes a bouncy castle, ball pool, and soft play with a mega mat setup, ideal for indoor and outdoor use.`,
  safetyHygiene: "All inflatables, soft play items, ball pools, and mats are fully sanitized for each hire, ensuring maximum safety and hygiene.",
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse',
    'Rothwell', 'Methley', 'Normanton', 'Featherstone',
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington',
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  dimensions: {
    toddlersBouncyCastle: {
      imperial: { width: '9ft', length: '11.5ft', height: '8ft', requiredSpace: { width: '12ft', length: '17ft', height: '8.5ft' }, accessWidth: '3ft' },
      metric: { width: '2.7m', length: '3.5m', height: '2.4m', requiredSpace: { width: '3.7m', length: '5.2m', height: '2.6m' }, accessWidth: '0.9m' }
    },
    ballPool: "Plain - Green / Light Blue",
    softPlay: "18pc & 9xMega Mat Set Up - Green / Light Blue"
  },
  suitability: [
    'Indoors on Hard Surface',
    'Outdoors on Artificial Grass',
    'Outdoors on Flags',
    'Outdoors on Grass',
    'Outdoors on Hard Surface'
  ],
  toddlersBouncyCastleSuitability: {
    for: 'Children',
    notFor: 'Adults',
    limitations: [
      'Not suitable outdoors on Artificial Grass',
      'Not suitable outdoors on Flags'
    ]
  },
  ballPoolSuitability: {
    for: 'Indoor and Outdoor use',
    surfaces: [
      'Indoors on Hard Surface',
      'Outdoors on Artificial Grass',
      'Outdoors on Flags',
      'Outdoors on Grass',
      'Outdoors on Hard Surface'
    ]
  },
  softPlaySuitability: {
    surfaces: [
      'Indoors on Hard Surface',
      'Outdoors on Artificial Grass',
      'Outdoors on Flags',
      'Outdoors on Grass',
      'Outdoors on Hard Surface'
    ]
  }
}
,
{
  price: 195,
  nextMorningCollection: 50,
  title: "Soft Play Bouncy Castle Juniors Package - Red / Blue",
  img: "/newProducts/soft-play-bouncy-castle-juniors-package-red-blue.png",
  images: [
  "/newProducts/soft-play-bouncy-castle-juniors-package-red-blue.png",
  ],
  description: `Premium Inflatables presents the Soft Play Bouncy Castle Juniors Package in Red & Blue. This inflatable package is designed for toddlers and young children, providing a fun and safe play environment. The setup includes a bouncy castle, ball pool, and soft play with a mega mat setup, ideal for both indoor and outdoor settings.`,
  safetyHygiene: "All inflatables, soft play items, ball pools, and mats are fully sanitized for each hire, ensuring maximum safety and hygiene.",
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse',
    'Rothwell', 'Methley', 'Normanton', 'Featherstone',
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington',
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  dimensions: {
    juniorsBouncyCastle: {
      imperial: { width: '9ft', length: '11.5ft', height: '8ft', requiredSpace: { width: '12ft', length: '17ft', height: '8.5ft' } },
      metric: { width: '2.7m', length: '3.5m', height: '2.4m', requiredSpace: { width: '3.7m', length: '5.2m', height: '2.6m' } }
    },
    ballPool: "Plain - Red / Blue",
    foamBallPool: "Foam Ball Pool - Red / Blue",
    softPlay: "18pc & 9xMega Mat Set Up - Red / Blue"
  },
  suitability: [
    'Indoors on Hard Surface',
    'Outdoors on Artificial Grass',
    'Outdoors on Flags',
    'Outdoors on Grass',
    'Outdoors on Hard Surface'
  ],
  juniorsBouncyCastleSuitability: {
    for: 'Children',
    notFor: 'Adults',
    limitations: [
      'Not suitable outdoors on Artificial Grass',
      'Not suitable outdoors on Flags'
    ]
  },
  ballPoolSuitability: {
    for: 'Indoor and Outdoor use',
    surfaces: [
      'Indoors on Hard Surface',
      'Outdoors on Artificial Grass',
      'Outdoors on Flags',
      'Outdoors on Grass',
      'Outdoors on Hard Surface'
    ]
  },
  foamBallPoolSuitability: {
    for: 'Indoor and Outdoor use',
    surfaces: [
      'Indoors on Hard Surface',
      'Outdoors on Artificial Grass',
      'Outdoors on Flags',
      'Outdoors on Grass',
      'Outdoors on Hard Surface'
    ]
  },
  softPlaySuitability: {
    surfaces: [
      'Indoors on Hard Surface',
      'Outdoors on Artificial Grass',
      'Outdoors on Flags',
      'Outdoors on Grass',
      'Outdoors on Hard Surface'
    ]
  }
}
,
{
  price: 245,
  title: "Soft Play Bouncy Castle Package - Green / Light Blue",
  img: "/newProducts/soft-play-bouncy-castle-package-green-light-blue.png",
  images: [
    "/newProducts/soft-play-bouncy-castle-package-green-light-blue1.png",
    "/newProducts/soft-play-bouncy-castle-package-green-light-blue2.png",
    "/newProducts/soft-play-bouncy-castle-package-green-light-blue3.png",
    "/newProducts/soft-play-bouncy-castle-package-green-light-blue4.png",
    
  ],
  description: `Premium Inflatables presents the Soft Play Bouncy Castle Package in Green & Light Blue. This premium inflatable setup offers a bouncy castle, ball pool, and a soft play area with a mega mat setup. Ideal for children, this package is available for both indoor and outdoor settings, ensuring a fun and safe experience.`,
  safetyHygiene: "All inflatables, soft play items, ball pools, and mats are fully sanitized for each hire, ensuring maximum safety and hygiene.",
  note: "Soft play and foam ball pools are not available for outdoor use. Please contact us for alternatives.",
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse',
    'Rothwell', 'Methley', 'Normanton', 'Featherstone',
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington',
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  dimensions: {
    bouncyCastle: {
      imperial: { width: '15ft', length: '12ft', height: '9.5ft', requiredSpace: { width: '21ft', length: '15ft', height: '10ft' } },
      metric: { width: '4.6m', length: '3.7m', height: '2.9m', requiredSpace: { width: '6.4m', length: '4.6m', height: '3.0m' } }
    },
    ballPool: "Plain - Green / Light Blue",
    softPlay: "18pc & 9xMega Mat Set Up - Green / Light Blue"
  },
  suitability: [
    'Indoors on Hard Surface',
    'Outdoors on Artificial Grass',
    'Outdoors on Flags',
    'Outdoors on Grass',
    'Outdoors on Hard Surface'
  ],
  bouncyCastleSuitability: {
    for: 'Children',
    notFor: 'Adults',
    limitations: [
      'Not suitable outdoors on Artificial Grass',
      'Not suitable outdoors on Flags'
    ]
  },
  ballPoolSuitability: {
    for: 'Indoor and Outdoor use',
    surfaces: [
      'Indoors on Hard Surface',
      'Outdoors on Artificial Grass',
      'Outdoors on Flags',
      'Outdoors on Grass',
      'Outdoors on Hard Surface'
    ]
  },
  softPlaySuitability: {
    surfaces: [
      'Indoors on Hard Surface',
      'Outdoors on Artificial Grass',
      'Outdoors on Flags',
      'Outdoors on Grass',
      'Outdoors on Hard Surface'
    ]
  }
}
,

{
  price: 245,
  title: "Soft Play Bouncy Castle Package - Pink / Purple",
  img: "/newProducts/soft-play-bouncy-castle-package-pink-purple.png",
  images: [
    "/newProducts/soft-play-bouncy-castle-package-pink-purple.png",
  ],
  description: `Premium Inflatables presents the Soft Play Bouncy Castle Package in Pink & Purple. This premium package offers a vibrant bouncy castle, ball pool, and a soft play area with a mega mat setup. Ideal for children, this package is perfect for both indoor and outdoor settings, providing a fun and sanitized experience.`,
  safetyHygiene: "All inflatables, soft play items, ball pools, and mats are fully sanitized for each hire, ensuring maximum safety and hygiene.",
  note: "Soft play and foam ball pools are not available for outdoor use. Please contact us for alternatives.",
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse',
    'Rothwell', 'Methley', 'Normanton', 'Featherstone',
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington',
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  dimensions: {
    bouncyCastle: {
      imperial: { width: '12ft', length: '15ft', height: '9.5ft', requiredSpace: { width: '15ft', length: '21ft', height: '10ft' } },
      metric: { width: '3.7m', length: '4.6m', height: '2.9m', requiredSpace: { width: '4.6m', length: '6.4m', height: '3.0m' } }
    },
    ballPool: "Plain - Pink / Purple",
    softPlay: "18pc & 9xMega Mat Set Up - Pink / Purple"
  },
  suitability: [
    'Indoors on Hard Surface',
    'Outdoors on Artificial Grass',
    'Outdoors on Flags',
    'Outdoors on Grass',
    'Outdoors on Hard Surface'
  ],
  bouncyCastleSuitability: {
    for: 'Children',
    notFor: 'Adults',
    limitations: [
      'Not suitable outdoors on Artificial Grass',
      'Not suitable outdoors on Flags'
    ]
  },
  ballPoolSuitability: {
    for: 'Indoor and Outdoor use',
    surfaces: [
      'Indoors on Hard Surface',
      'Outdoors on Artificial Grass',
      'Outdoors on Flags',
      'Outdoors on Grass',
      'Outdoors on Hard Surface'
    ]
  },
  softPlaySuitability: {
    surfaces: [
      'Indoors on Hard Surface',
      'Outdoors on Artificial Grass',
      'Outdoors on Flags',
      'Outdoors on Grass',
      'Outdoors on Hard Surface'
    ]
  }
}
,

{
  price: 295,
  title: "Soft Play + Slide + Bouncy Castle - Green / Light Blue",
  img: "/newProducts/soft-play-slide-bouncy-castle-green-light-blue.png",
  images: [
   "/newProducts/soft-play-slide-bouncy-castle-green-light-blue.png",
  ],
  description: `Premium Inflatables brings you the Soft Play + Slide + Bouncy Castle Package in Green & Light Blue. This premium package includes a bouncy castle, mini platform slide, foam ball pool, soft play pieces, and matching mats. Ideal for children's parties and events, this modern setup with a gloss finish is designed to keep kids entertained both indoors and outdoors.`,
  safetyHygiene: "All inflatables, soft play items, ball pools, and mats are fully sanitized for each hire, ensuring maximum safety and hygiene.",
  note: "This soft play and foam ball pool are not suitable for outdoor use. Please contact us for alternatives.",
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse',
    'Rothwell', 'Methley', 'Normanton', 'Featherstone',
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington',
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  dimensions: {
    bouncyCastle: {
      imperial: { width: '9ft', length: '11ft', height: '8ft', requiredSpace: { width: '12ft', length: '17ft', height: '8.5ft' } },
      metric: { width: '2.7m', length: '3.5m', height: '2.4m', requiredSpace: { width: '3.7m', length: '5.2m', height: '2.6m' } }
    },
    slide: {
      imperial: { width: '12ft', length: '12ft', height: '8ft', slidePlatformHeight: '5ft' },
      metric: { width: '3.7m', length: '3.7m', height: '2.4m', slidePlatformHeight: '1.5m' }
    },
    foamBallPool: "Foam Ball Pool - Green / Light Blue",
    softPlay: "18pc & 9xMega Mat Set Up - Green / Light Blue"
  },
  suitability: [
    'Indoors on Hard Surface',
    'Outdoors on Artificial Grass',
    'Outdoors on Flags',
    'Outdoors on Grass',
    'Outdoors on Hard Surface'
  ],
  bouncyCastleSuitability: {
    for: 'Children',
    notFor: 'Adults',
    limitations: [
      'Not suitable outdoors on Artificial Grass',
      'Not suitable outdoors on Flags'
    ]
  },
  ballPoolSuitability: {
    for: 'Indoor and Outdoor use',
    surfaces: [
      'Indoors on Hard Surface',
      'Outdoors on Artificial Grass',
      'Outdoors on Flags',
      'Outdoors on Grass',
      'Outdoors on Hard Surface'
    ]
  },
  slideSuitability: {
    for: 'Children',
    notFor: 'Adults',
    limitations: [
      'Not suitable outdoors on Artificial Grass',
      'Not suitable outdoors on Flags'
    ]
  },
  softPlaySuitability: {
    surfaces: [
      'Indoors on Hard Surface',
      'Outdoors on Artificial Grass',
      'Outdoors on Flags',
      'Outdoors on Grass',
      'Outdoors on Hard Surface'
    ]
  }
}
,
{
  price: 195,
  title: "Superheroes Juniors Slide + Bouncy Castle - Green / Light Blue",
  img: "/newProducts/superheroes-juniors-slide-bouncy-castle-green-light-blue.png",
  images: [
    "/newProducts/superheroes-juniors-slide-bouncy-castle-green-light-blue.png",
   
  ],
  description: `The Superheroes Juniors Slide + Bouncy Castle in Green & Light Blue is a thrilling addition to any children's party or event. This package includes a superheroes-themed bouncy castle paired with a matching slide. The setup features classic cartoon party-time artwork with a modern gloss finish, perfect for both indoor and outdoor events.`,
  safetyHygiene: "All inflatables, soft play items, ball pools, and mats are fully sanitized for each hire, ensuring maximum safety and hygiene.",
  note: "Add-ons like Didi Cars and Hoppers are available to enhance the package, providing fun and versatility for both indoor and outdoor use.",
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse',
    'Rothwell', 'Methley', 'Normanton', 'Featherstone',
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington',
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  dimensions: {
    bouncyCastle: {
      imperial: { width: '9ft', length: '11.5ft', height: '8ft', requiredSpace: { width: '12ft', length: '17ft', height: '8.5ft' } },
      metric: { width: '2.7m', length: '3.5m', height: '2.4m', requiredSpace: { width: '3.7m', length: '5.2m', height: '2.6m' } }
    },
    slide: {
      imperial: { width: '12ft', length: '12ft', height: '8ft', slidePlatformHeight: '5ft' },
      metric: { width: '3.7m', length: '3.7m', height: '2.4m', slidePlatformHeight: '1.5m' }
    }
  },
  suitability: [
    'Indoors on Hard Surface',
    'Outdoors on Artificial Grass',
    'Outdoors on Flags',
    'Outdoors on Grass',
    'Outdoors on Hard Surface'
  ],
  bouncyCastleSuitability: {
    for: 'Children',
    notFor: 'Adults',
    limitations: [
      'Not suitable outdoors on Artificial Grass',
      'Not suitable outdoors on Flags'
    ]
  },
  slideSuitability: {
    for: 'Children',
    notFor: 'Adults',
    limitations: [
      'Not suitable outdoors on Artificial Grass',
      'Not suitable outdoors on Flags'
    ]
  }
}
,
{
  price: 195,
  title: "Superheroes Juniors Slide + Bouncy Castle - Red / Blue",
  img: "/newProducts/superheroes-juniors-slide-bouncy-castle-red-blue.png",
  images: [
    "/newProducts/superheroes-juniors-slide-bouncy-castle-red-blue.png",

  ],
  description: `The Superheroes Juniors Slide + Bouncy Castle in Red & Blue is a fantastic choice for children's parties or events. Featuring superheroes-themed designs, this bouncy castle and slide combo offers both fun and safety for the kids. The package showcases vibrant colors and a modern glossy finish, suitable for both indoor and outdoor use.`,
  safetyHygiene: "All inflatables, soft play items, ball pools, and mats are thoroughly sanitized before every use, prioritizing safety and hygiene.",
  note: "Consider adding Didi Cars and Hoppers to the package, which are versatile and fun for kids, suitable for both indoor and outdoor events.",
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse',
    'Rothwell', 'Methley', 'Normanton', 'Featherstone',
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington',
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  dimensions: {
    bouncyCastle: {
      imperial: { width: '9ft', length: '11.5ft', height: '8ft', requiredSpace: { width: '12ft', length: '17ft', height: '8.5ft' } },
      metric: { width: '2.7m', length: '3.5m', height: '2.4m', requiredSpace: { width: '3.7m', length: '5.2m', height: '2.6m' } }
    },
    slide: {
      imperial: { width: '12ft', length: '12ft', height: '8ft', slidePlatformHeight: '5ft' },
      metric: { width: '3.7m', length: '3.7m', height: '2.4m', slidePlatformHeight: '1.5m' }
    }
  },
  suitability: [
    'Indoors on Hard Surface',
    'Outdoors on Artificial Grass',
    'Outdoors on Flags',
    'Outdoors on Grass',
    'Outdoors on Hard Surface'
  ],
  bouncyCastleSuitability: {
    for: 'Children',
    notFor: 'Adults',
    limitations: [
      'Not suitable outdoors on Artificial Grass',
      'Not suitable outdoors on Flags'
    ]
  },
  slideSuitability: {
    for: 'Children',
    notFor: 'Adults',
    limitations: [
      'Not suitable outdoors on Artificial Grass',
      'Not suitable outdoors on Flags'
    ]
  }
}
,

{
  price: 195,
  title: "Superheroes Soft Play Bouncy Castle Juniors Package - Green / Light Blue",
  img: "/newProducts/superheroes-soft-play-bouncy-castle-juniors-package-green-light-blue.png",
  images: [
    "/newProducts/superheroes-soft-play-bouncy-castle-juniors-package-green-light-blue!!!.png",
    "/newProducts/superheroes-soft-play-bouncy-castle-juniors-package-green-light-blue!!.png",
      "/newProducts/superheroes-soft-play-bouncy-castle-juniors-package-green-light-blue!.png",
        "/newProducts/superheroes-soft-play-bouncy-castle-juniors-package-green-light-blue!!.png"
  ],
  description: `The Superheroes Soft Play Bouncy Castle Juniors Package in Green and Light Blue is the perfect addition to any children's party or event. Featuring vibrant cartoon Superheroes artwork, this package includes a themed bouncy castle, foam ball pool, 18 pieces of soft play, and a 9 Mega mat setup. This premium package offers safety and hygiene, with all items thoroughly sanitized before each use.`,
  safetyHygiene: "Safety and Hygiene are the paramount priority at Premium Inflatables! All our inflatables, soft play, ball pools, and mats come fully sanitized for every use.",
  note: "Consider adding Didi Cars and Hoppers for extra fun. These safe, easy-to-use toys are perfect for indoor and outdoor events.",
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse',
    'Rothwell', 'Methley', 'Normanton', 'Featherstone',
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington',
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  dimensions: {
    bouncyCastle: {
      imperial: { width: '9ft', length: '11.5ft', height: '8ft', requiredSpace: { width: '12ft', length: '17ft', height: '8.5ft' } },
      metric: { width: '2.7m', length: '3.5m', height: '2.4m', requiredSpace: { width: '3.7m', length: '5.2m', height: '2.6m' } }
    },
    foamBallPool: {
      suitability: [
        'Indoors on Hard Surface',
        'Outdoors on Artificial Grass',
        'Outdoors on Flags',
        'Outdoors on Grass',
        'Outdoors on Hard Surface'
      ]
    },
    softPlay: {
      suitability: [
        'Indoors on Hard Surface',
        'Outdoors on Artificial Grass',
        'Outdoors on Flags',
        'Outdoors on Grass',
        'Outdoors on Hard Surface'
      ]
    }
  },
  suitability: {
    for: 'Children',
    notFor: 'Adults'
  },
  additionalActivities: [
    {
      name: "Didi Cars & Hoppers",
      description: "Super Fun optional extras to keep everyone occupied. Kids can hop on and start wiggling, perfect for indoor and outdoor use."
    },
    {
      name: "Giant Connect 4 Game",
      description: "Every child loves competing in this classic game."
    }
  ],
  largerOptions: "If you require a larger bouncy castle for more maximum users, check out our Bigger Bouncy Castle Indoor Soft Play Packages.",
  whyChoose: "Choose Premium Inflatables for trained delivery and setup at your chosen home or venue."
}
,

{
  price: 195,
  title: "Superheroes Soft Play Bouncy Castle Juniors Package - Red / Blue",
  img: "/newProducts/superheroes-soft-play-bouncy-castle-juniors-package-red-blue.png",
  images: [
    "/newProducts/superheroes-soft-play-bouncy-castle-juniors-package-red-blue1.png",
    "/newProducts/superheroes-soft-play-bouncy-castle-juniors-package-red-blue2.png",
    "/newProducts/superheroes-soft-play-bouncy-castle-juniors-package-red-blue3.png",
    "/newProducts/superheroes-soft-play-bouncy-castle-juniors-package-red-blue4.png",
    "/newProducts/superheroes-soft-play-bouncy-castle-juniors-package-red-blue5.png",
    "/newProducts/superheroes-soft-play-bouncy-castle-juniors-package-red-blue6.png",

  
  ],
  description: `The Superheroes Soft Play Bouncy Castle Juniors Package in Red and Blue is the ultimate choice for any children's party! This impressive package features a themed bouncy castle, a foam ball pool, a matching 17-piece Superheroes soft play set, and a Mega mat setup. Ideal for both indoor and outdoor hires, this bouncy castle guarantees fun, no matter the season!`,
  safetyHygiene: "Safety and Hygiene are paramount at Premium Inflatables! All inflatables, soft play, ball pools, and mats are fully sanitized for every use.",
  note: "Consider adding our fun 4x Didi Cars and 4x Animal Hoppers to keep your little Superheroes entertained!",
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse',
    'Rothwell', 'Methley', 'Normanton', 'Featherstone',
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington',
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  dimensions: {
    bouncyCastle: {
      imperial: { width: '9ft', length: '11.5ft', height: '8ft', requiredSpace: { width: '12ft', length: '17ft', height: '8.5ft' } },
      metric: { width: '2.7m', length: '3.5m', height: '2.4m', requiredSpace: { width: '3.7m', length: '5.2m', height: '2.6m' } }
    },
    foamBallPool: {
      suitability: [
        'Indoors on Hard Surface',
        'Outdoors on Artificial Grass',
        'Outdoors on Flags',
        'Outdoors on Grass',
        'Outdoors on Hard Surface'
      ]
    },
    softPlay: {
      suitability: [
        'Indoors on Hard Surface',
        'Outdoors on Artificial Grass',
        'Outdoors on Flags',
        'Outdoors on Grass',
        'Outdoors on Hard Surface'
      ]
    }
  },
  suitability: {
    for: 'Children',
    notFor: 'Adults'
  },
  additionalActivities: [
    {
      name: "Didi Cars & Hoppers",
      description: "Add fun with 4x Didi Cars and 4x Animal Hoppers to keep the kids entertained!"
    }
  ],
  largerOptions: "If you need a larger bouncy castle for more users, check out our Bigger Bouncy Castle Indoor Soft Play Packages.",
  whyChoose: "Choose Premium Inflatables for trained delivery and setup at your chosen home or venue."
}
,

{
  price: 245,
  title: "Superheroes Soft Play Bouncy Castle Package - Red / Blue",
  img: "/newProducts/superheroes-soft-play-bouncy-castle-package-red-blue.png",
  images: [
    "/newProducts/superheroes-soft-play-bouncy-castle-package-red-blue1.png",
    "/newProducts/superheroes-soft-play-bouncy-castle-package-red-blue2.png",
    "/newProducts/superheroes-soft-play-bouncy-castle-package-red-blue3.png",
    "/newProducts/superheroes-soft-play-bouncy-castle-package-red-blue4.png",
    "/newProducts/superheroes-soft-play-bouncy-castle-package-red-blue5.png",
  
  ],
  description: `The Superheroes Soft Play Bouncy Castle Package in Red and Blue is the perfect choice for your children's birthday party! Featuring a spacious 12ft x 15ft bouncy castle with a height of 9.5ft, this package is ideal for indoor hires. It includes a foam ball pool, 17-piece matching Superhero soft play, and a red/blue Mega mat setup, ensuring endless entertainment for children of all ages.`,
  safetyHygiene: "Safety and Hygiene are paramount at Premium Inflatables! All inflatables, soft play, ball pools, and mats are fully sanitized for every use.",
  note: "Consider adding our fun 4x Didi Cars and 4x Hoppers to keep your little monkeys entertained!",
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse',
    'Rothwell', 'Methley', 'Normanton', 'Featherstone',
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington',
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  dimensions: {
    bouncyCastle: {
      imperial: { width: '12ft', length: '15ft', height: '9.5ft', requiredSpace: { width: '15ft', length: '21ft', height: '10ft' }, accessWidth: '3ft' },
      metric: { width: '3.7m', length: '4.6m', height: '2.9m', requiredSpace: { width: '4.6m', length: '6.4m', height: '3.0m' }, accessWidth: '0.9m' }
    },
    foamBallPool: {
      suitability: [
        'Indoors on Hard Surface',
        'Outdoors on Artificial Grass',
        'Outdoors on Flags',
        'Outdoors on Grass',
        'Outdoors on Hard Surface'
      ]
    },
    softPlay: {
      suitability: [
        'Indoors on Hard Surface',
        'Outdoors on Artificial Grass',
        'Outdoors on Flags',
        'Outdoors on Grass',
        'Outdoors on Hard Surface'
      ]
    }
  },
  suitability: {
    for: 'Children',
    notFor: 'Adults'
  },
  additionalActivities: [
    {
      name: "Didi Cars & Hoppers",
      description: "Add fun with 4x Didi Cars and 4x Animal Hoppers to keep the kids entertained!"
    }
  ],
  largerOptions: "If you need a larger bouncy castle for more users, check out our Bigger Bouncy Castle Indoor Soft Play Packages.",
  whyChoose: "Choose Premium Inflatables for trained delivery and setup at your chosen home or venue."
}
,

{
  price: 195,
  title: "Bouncy Castle - Pink / Purple",
  img: "/newProducts/unicorn-juniors-slide-bouncy-castle-pink-purple.png",
  images: [
    "/newProducts/unicorn-juniors-slide-bouncy-castle-pink-purple1.png",
    "/newProducts/unicorn-juniors-slide-bouncy-castle-pink-purple2.png",
    "/newProducts/unicorn-juniors-slide-bouncy-castle-pink-purple3.png",
   
  ],
  description: `Introducing our Unicorn Themed Bouncy Castle and Slide Package in Pink and Purple, an amazing addition to any children's birthday party or event. This package features classic cartoon unicorn artwork, finished in a modern gloss, ensuring it stands out at any occasion. It's perfect for indoor and outdoor events, and can be easily upgraded with ball pools, soft play, and matching mat setups for a complete experience.`,
  safetyHygiene: "Safety and Hygiene are paramount at Premium Inflatables! All inflatables, soft play, ball pools, and mats are fully sanitized for every use.",
  note: "Consider adding our package of Didi Cars and Hoppers to your party for extra fun!",
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse',
    'Rothwell', 'Methley', 'Normanton', 'Featherstone',
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington',
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  dimensions: {
    bouncyCastle: {
      imperial: { width: '9ft', length: '11.5ft', height: '8ft', requiredSpace: { width: '12ft', length: '17ft', height: '8.5ft' }, accessWidth: '3ft' },
      metric: { width: '2.7m', length: '3.5m', height: '2.4m', requiredSpace: { width: '3.7m', length: '5.2m', height: '2.6m' }, accessWidth: '0.9m' }
    },
    slide: {
      imperial: { width: '12ft', length: '12ft', height: '8ft', requiredSpace: { width: '15ft', length: '17ft', height: '9ft' }, platformHeight: '5ft' },
      metric: { width: '3.7m', length: '3.7m', height: '2.4m', requiredSpace: { width: '4.6m', length: '5.2m', height: '2.7m' }, platformHeight: '1.5m' }
    }
  },
  suitability: {
    for: 'Children',
    notFor: 'Adults'
  },
  additionalActivities: [
    {
      name: "Didi Cars & Hoppers",
      description: "Add super fun Didi Cars and Hoppers to your package for safe and easy entertainment for kids!"
    }
  ],
  largerOptions: "If you need a larger bouncy castle for more users, check out our Bigger Bouncy Castle Indoor Soft Play Packages.",
  whyChoose: "Choose Premium Inflatables for trained delivery and setup at your chosen home or venue."
}
,
{
  price: 195,
  title: "Unicorn Soft Play Bouncy Castle Juniors Package - Pink / Purple",
  img: "/newProducts/unicorn-soft-play-bouncy-castle-juniors-package-pink-purple.png",
  images: [
    "/newProducts/unicorn-soft-play-bouncy-castle-juniors-package-pink-purple1.png",
    "/newProducts/unicorn-soft-play-bouncy-castle-juniors-package-pink-purple2.png",
    "/newProducts/unicorn-soft-play-bouncy-castle-juniors-package-pink-purple3.png",
    
  ],
  description: `Introducing our Unicorn Soft Play Bouncy Castle Juniors Package in Pink and Purple, perfect for your little girls who adore My Little Pony! This vibrant package includes a colourful Unicorn Themed Bouncy Castle, a foam ball pool, 18 pieces of soft play, and a matching 9x mat setup. This safe environment allows kids to roll, play, and pretend to be beautiful unicorns! Ideal for indoor venues, this package features a 9x11ft Toddler Castle.`,
  safetyHygiene: "Safety and Hygiene are paramount at Premium Inflatables! All inflatables, soft play, ball pools, and mats are fully sanitized for every use.",
  additionalActivities: [
    {
      name: "Didi Cars & Hoppers",
      description: "Add super fun Didi Cars and Hoppers to your package! They are safe, fun, and easy to use, allowing kids to hop on and start wiggling! Perfect for both indoor and outdoor use."
    },
    {
      name: "Giant Connect 4 Game",
      description: "Every child loves the challenge of catching 4x in a row with our Giant Connect 4 Game."
    }
  ],
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse',
    'Rothwell', 'Methley', 'Normanton', 'Featherstone',
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington',
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  dimensions: {
    bouncyCastle: {
      imperial: { width: '9ft', length: '11.5ft', height: '8ft', requiredSpace: { width: '12ft', length: '17ft', height: '8.5ft' }, accessWidth: '3ft' },
      metric: { width: '2.7m', length: '3.5m', height: '2.4m', requiredSpace: { width: '3.7m', length: '5.2m', height: '2.6m' }, accessWidth: '0.9m' }
    },
    foamBallPool: {
      imperial: { width: 'varies', length: 'varies', height: 'varies', suitableFor: 'Indoor and Outdoor' },
      metric: { width: 'varies', length: 'varies', height: 'varies', suitableFor: 'Indoor and Outdoor' }
    },
    softPlay: {
      imperial: { pcs: '18', matSize: '9x', suitableFor: 'Indoor and Outdoor' },
      metric: { pcs: '18', matSize: '9x', suitableFor: 'Indoor and Outdoor' }
    }
  },
  suitability: {
    for: 'Children',
    notFor: 'Adults'
  },
  largerOptions: "For larger groups, look up our Bigger Bouncy Castle Indoor Soft Play Packages.",
  whyChoose: "Choose Premium Inflatables for trained delivery and setup at your chosen home or venue."
}
,

{
  price: 245,
  title: "Unicorn Soft Play Bouncy Castle Package - Pink / Purple",
  img: "/newProducts/unicorn-soft-play-bouncy-castle-package-pink-purple.png",
  images: [
    "/newProducts/unicorn-soft-play-bouncy-castle-package-pink-purple1.png",
    "/newProducts/unicorn-soft-play-bouncy-castle-package-pink-purple2.png",
    "/newProducts/unicorn-soft-play-bouncy-castle-package-pink-purple3.png",
    "/newProducts/unicorn-soft-play-bouncy-castle-package-pink-purple4.png",
    "/newProducts/unicorn-soft-play-bouncy-castle-package-pink-purple5.png",
  
  ],
  description: `Introducing our Unicorn Soft Play Bouncy Castle Package in Pink and Purple, perfect for little girls who love My Little Pony! This vibrant package includes a 12x15ft Unicorn Themed Bouncy Castle, a foam ball pool, 17 pieces of soft play, and a matching 9 mat setup. This safe environment allows kids to roll, play, and pretend to be beautiful unicorns! Ideal for all indoor venues.`,
  safetyHygiene: "Safety and Hygiene are paramount at Premium Inflatables! All inflatables, soft play, ball pools, and mats are fully sanitized for every use.",
  additionalActivities: [
    {
      name: "Didi Cars & Hoppers",
      description: "Add fun Didi cars and animal hoppers to your package to keep the kids entertained throughout the party!"
    }
  ],
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse',
    'Rothwell', 'Methley', 'Normanton', 'Featherstone',
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington',
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  dimensions: {
    bouncyCastle: {
      imperial: { width: '12ft', length: '15ft', height: '9.5ft', requiredSpace: { width: '15ft', length: '21ft', height: '10ft' }, accessWidth: '3ft' },
      metric: { width: '3.7m', length: '4.6m', height: '2.9m', requiredSpace: { width: '4.6m', length: '6.4m', height: '3.0m' }, accessWidth: '0.9m' }
    },
    foamBallPool: {
      imperial: { width: 'varies', length: 'varies', height: 'varies', suitableFor: 'Indoor and Outdoor' },
      metric: { width: 'varies', length: 'varies', height: 'varies', suitableFor: 'Indoor and Outdoor' }
    },
    softPlay: {
      imperial: { pcs: '17', matSize: '9x', suitableFor: 'Indoor and Outdoor' },
      metric: { pcs: '17', matSize: '9x', suitableFor: 'Indoor and Outdoor' }
    }
  },
  suitability: {
    for: 'Children',
    notFor: 'Adults'
  },
  largerOptions: "For larger groups, please contact us for alternative packages.",
  whyChoose: "Choose Premium Inflatables for trained delivery and setup at your chosen home or venue.",
  nextMorningCollection: {
    available: true,
    fee: 50
  }
}
,

{
  price: 295,
  title: "Unicorn Soft Play + Slide + Bouncy Castle - Pink / Purple",
  img: "/newProducts/unicorn-soft-play-slide-bouncy-castle-pink-purple.png",
  images: [
    "/newProducts/unicorn-soft-play-slide-bouncy-castle-pink-purple1.png",
  
  ],
  description: `Introducing the Unicorn Soft Play + Slide + Bouncy Castle Package in Pink and Purple! Perfect for birthday celebrations, this mystical-themed package includes a 9x11ft Unicorn Bouncy Castle, a 12ft x 12ft Mini Pink Purple Slide, a foam ball pool, 17 pieces of soft play, and a matching 9 mat setup. It's ideal for both indoor and outdoor events, allowing your little ones to celebrate their special day in style!`,
  safetyHygiene: "Safety and Hygiene are paramount at Premium Inflatables! All inflatables, soft play, ball pools, and mats come fully sanitized for every use.",
  additionalActivities: [
    {
      name: "Didi Cars & Hoppers",
      description: "Add 4 Didi cars and 4 hoppers to your package for extra fun and entertainment!"
    }
  ],
  contactInfo: {
    phone: "0113 460 1386",
    email: "info@premiuminflatables.co.uk",
    bookingOnline: true
  },
  availableLocations: [
    'Leeds', 'Wakefield', 'Tingley', 'Morley', 'Lofthouse',
    'Rothwell', 'Methley', 'Normanton', 'Featherstone',
    'Pontefract', 'Castleford', 'Knottingley', 'Darrington',
    'Wentbridge', 'Sherburn in Elmet', 'Selby & surroundings'
  ],
  dimensions: {
    bouncyCastle: {
      imperial: { width: '9ft', length: '11.5ft', height: '8ft', requiredSpace: { width: '12ft', length: '17ft', height: '8.5ft' }, accessWidth: '3ft' },
      metric: { width: '2.7m', length: '3.5m', height: '2.4m', requiredSpace: { width: '3.7m', length: '5.2m', height: '2.6m' }, accessWidth: '0.9m' }
    },
    slide: {
      imperial: { width: '12ft', length: '12ft', height: '8ft', requiredSpace: { width: '15ft', length: '17ft', height: '9ft' }, slidePlatformHeight: '5ft' },
      metric: { width: '3.7m', length: '3.7m', height: '2.4m', requiredSpace: { width: '4.6m', length: '5.2m', height: '2.7m' }, slidePlatformHeight: '1.5m' }
    },
    foamBallPool: {
      imperial: { suitableFor: 'Indoor and Outdoor' },
      metric: { suitableFor: 'Indoor and Outdoor' }
    },
    softPlay: {
      imperial: { pcs: '17', matSize: '9x', suitableFor: 'Indoor and Outdoor' },
      metric: { pcs: '17', matSize: '9x', suitableFor: 'Indoor and Outdoor' }
    }
  },
  suitability: {
    for: 'Children',
    notFor: 'Adults'
  },
  whyChoose: "Choose Premium Inflatables for trained delivery and setup at your chosen home or venue.",
  nextMorningCollection: {
    available: true,
    fee: 50
  }
}

];

export const cardImages = [
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_200/6865b8be3d792e5bb053e865cf12e0c0",
    title: "BOUNCY CASTLES",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_300/1a4e19283419389a24d290be6f8efe74",
    title: "Disco Demos",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_300/e68b600c7c0430c764960ab35b15234d",
    title: "Events",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_300/cc8f7950e83ac2ff687636b98bfdf2f5",
    title: "Hot tub",
  },
];
export const slideImages = [
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_1400/e7a060be3e14bc867deb1cfd31d9511e",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_1400/5f81824ee215558f0cec8c06cc16f662",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_1400/e7a060be3e14bc867deb1cfd31d9511e",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_1400/dab121678cd0d815daca70d560c82929",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_1400/32f9f40f9f1d718960b059fcfef0aa4f",
  },

  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_1400/5c4168b4d8580c737c6fd590117462b7",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_1400/5c4168b4d8580c737c6fd590117462b7",
  },
  {
    img: "https://bouncycastlenetwork-res.cloudinary.com/image/upload/f_auto,q_auto,c_limit,w_1400/c03e1e353a9a9544f5e0f813726e4e0b",
  },
  {
    img: "/images/IMG-20240815-WA0016.jpg",
  },
  {
    img: "/images/IMG-20240815-WA0017.jpg",
  },
  {
    img: "/images/IMG-20240815-WA0030.jpg",
  },
];
export const navData = [
  {
    title: "Home",
    url: "/",
  },
  {
    title: "Products",
    url: "#",
    submenu: [
      { title: "New For 2024!", url: "/category/news-2024" },
      { title: "Indoor Soft Play Packages", url: "/category/indoor-soft-play" },
      { title: "Christmas Inflatables", url: "/category/chrismis-inflatables" },
      { title: "Bouncy Castles", url: "/category/bouncy-castles" },
      { title: "Disco Domes", url: "/category/disco-domes" },
      { title: "Assault Course", url: "/category/asult-course" },
      { title: "Bounce & Slide Combos", url: "/category/bounce-slide-combos" },
      { title: "ADULT CASTLES", url: "/category/adult-castles" },
      { title: "Soft Play", url: "/category/soft-play" },
      { title: "Party Add-ons", url: "/category/party-add-ons" },
      { title: "Music Amps", url: "/category/music-amps" },
      { title: "Inflatable Games", url: "/category/inflatable-games" },
      {
        title: "Generator Hire Section",
        url: "/category/generator-hier-section",
      },
      { title: "Party Entertainer", url: "/category/party-entertainer" },
    ],
  },
  {
    title: "Events",
    url: "/downloadParty",
  },

  // {
  //   title: "About",
  //   url: "/about",
  // },
  {
    title: "Privacy policy",
    url: "/privacy",
  },
  // {
  //   title: "Faqs",
  //   url: "/faqs",
  // },
  {
    title: "Cancellation",
    url: "/cancellation",
  },
  {
    title: "Contact us",
    url: "/contact",
  },
  {
    type: "text",
    placeholder: "search",
  },
  // {
  //   title: "Term and condition",
  //   url: "/termandcondition",
  // },
];
export const DownloadPartiesData = [
  {
    img: "https://files.bookingonline.co.uk/image/upload/c_scale,f_auto,fl_lossy,q_auto:eco,w_600/downloads/invitation-animals-1.png",
    title: "Animals invite (1)",
  },
  {
    img: "https://files.bookingonline.co.uk/image/upload/c_scale,f_auto,fl_lossy,q_auto:eco,w_600/downloads/invitation-animals-2.png",
    title: "Animals invite (2)",
  },
  {
    img: "https://files.bookingonline.co.uk/image/upload/c_scale,f_auto,fl_lossy,q_auto:eco,w_600/downloads/birthday-1.png",
    title: "Birthday (1)",
  },
  {
    img: "https://files.bookingonline.co.uk/image/upload/c_scale,f_auto,fl_lossy,q_auto:eco,w_600/downloads/birthday-2.png",
    title: "Birthday (2)",
  },
  {
    img: "https://files.bookingonline.co.uk/image/upload/c_scale,f_auto,fl_lossy,q_auto:eco,w_600/downloads/birthday-3.png",
    title: "Birthday (3)",
  },
  {
    img: "https://files.bookingonline.co.uk/image/upload/c_scale,f_auto,fl_lossy,q_auto:eco,w_600/downloads/birthday-4.png",
    title: "Birthday (4)",
  },
  {
    img: "https://files.bookingonline.co.uk/image/upload/c_scale,f_auto,fl_lossy,q_auto:eco,w_600/downloads/birthday-5.png",
    title: "Birthday (5)",
  },
  {
    img: "https://files.bookingonline.co.uk/image/upload/c_scale,f_auto,fl_lossy,q_auto:eco,w_600/downloads/birthday-6.png",
    title: "Birthday (6)",
  },
];
export const faqData = [
  {
    title: "What times do you deliver and collect the bouncy castle?",
    info: "Unless other arrangements have been made at time of booking we schedule to do all our deliveries in the morning between 8am – 12noon, and start collecting them in again from 6pm. We find that these times suit most people, as parties are generally in the afternoon. It just depends how busy we are, and what areas we are covering, as to what time we collect from each house. However, if your party is starting earlier, or going on a bit later, we are happy to discuss delivery and collection times to suit your party times.",
  },
  {
    title: "How much space is needed for a bouncy castle?",
    info: "Ideally, you need a 3ft gap each side of the castle, this leaves us enough room to stake it down. Behind the castle, you need a 5ft gap as this is where the fan has to go and placed far enough away from the rear of the castle to prevent injury should someone fall from the rear wall. In front of the castle you need to make sure you have a clear area so children can get on and off safely, about a 5ft gap minimum.",
  },
  {
    title: "Is there anything I need to do?",
    info: "No, we do all the heavy work so you can get on with preparations for your party. All we ask is that, before we arrive, you clear a passageway for us to pull the trolley through with the bouncy castle on (minimum 3ft gap). Make sure you have left enough room for us to get pass any parked cars on the driveway, we don’t want to scrape pass your pride and joy, and that you have cleared a big enough space in the garden where you want us to put the castle, ie, cleared the area of any animal soil, sharp objects (ie washing line holes) or any other debris..",
  },
  {
    title: "Do I need to supply anything?",
    info: "We need access to a plug socket to plug in our extension lead. Preferrably trailing the lead from a window not a door to avoid the cable being trapped/damaged should the door get closed. We carry 25mtr and 40mtr extension leads on the van, (that’s about 75ft and 120ft in old money!). Please let us know at time of booking if the inflatable will be further away from an electric point than that as you may need a petrol fan or generator which can be booked in advance at extra cost.",
  },
  {
    title: "How long does it take to set up the inflatable?",
    info: "On average it takes about 15-20 minutes in total to deliver and set up a bouncy castle or slide, and about 25-35 minutes for an obstacle course, this is assuming we have good access and the area is cleared where the inflatable is going.",
  },
  {
    title: "Do you have insurance?",
    info: "Yes. We have £5million Public Liability insurance. This covers you when we are delivering/collecting the inflatable, setting up and pulling down, if the unfortunate was to happen and we should damage any of your property, you have peace of mind that you can claim off our insurance. But rest assured – we are professional in our approach, and take every care and have never had a claim yet. Once the castle is erected, we will run through a few basic safety checks, pointing out any risk areas and ask you to sign a copy of our terms and safety procedures. Once we have left the site, the supervision of the inflatable and it’s users is down to the hirer.",
  },
  {
    title: "Can I take out my own insurance against accidents?",
    info: "In most cases, your own domestic house insurance will already cover you for the bouncy castle and it’s users. If this is something you are worried about, call your insurance company and discuss this with them. If you are not covered already, they may be able to issue you with a short term policy to cover the party for a small fee!",
  },
  {
    title: "Can adults go on the inflatables?",
    info: "Sorry NO! Unless you have hired an “Adult “ inflatable they are not permitted to go on and would not be covered if anything was to happen. Adult bouncy castles are made differently with deeper beds and higher walls to accommodate adults or “big kids”. If adults use our inflatables and they get damaged, it is the responsibility of the hirer to pay for any repairs or replacments, so please – NO ADULTS!",
  },
];
export const contactData = [
  {
    title: "Call or Text us on:",
    info: "07531522289",
  },
  {
    title: "Email us:",
    info: "enquiries@funrides.co.uk",
  },
  {
    title: "Add us on:",
    info: "Facebook",
  },
  {
    title: "Follow us on:",
    info: "Twitter",
  },
  {
    title: "Leave us a review on:",
    info: "Google+",
  },
  {
    title: "Subscribe to our:",
    info: "YouTube Channel",
  },
];
export const termandconditionData = [
  {
    info: "1. Fun Factor Leeds(the company) accepts no responsibility for loss, damage or injury to persons or their property during the hire of the equipment, unless if is proved beyond reasonable doubt that the company is at fault.",
  },
  {
    info: "2. It is the hirer’s responsibility to ensure that the equipment is fully supervised by a responsible adult at ALL TIMES.",
  },
  {
    info: "3. NO persons over the age of 15 are permitted on the equipment unless stated ADULT on the Hire Agreement.",
  },
  {
    info: "4. NO persons under the influence of alcohol, drugs or any other intoxicating substance are allowed on the equipment.",
  },
  {
    info: "5. NO shoes, food, drink, pets, toys and/or sharp implements are permitted on or near the inflatable, safety mats and/or equipment.",
  },
  {
    info: "6. NO silly string, streamers, party poppers or similar on or near the inflatable/equipment. These such products stain, and are difficult to remove. The cost of cleaning will be charged to the hirer at £30 per hour plus costs.",
  },
  {
    info: "7. NO water and/or hosepipes are permitted on the equipment",
  },
  {
    info: "8. NO climbing on the sides, roof or supporting beams of the inflatable/equipment",
  },
  {
    info: "9. NO jumping or somersaults from the top/platforms. Slides are to be used by sliding down feet first only.",
  },
  {
    info: "10. Do NOT allow users on the inflatable at the time of inflation or deflation.",
  },
  {
    info: "11. Do NOT allow any heat/fire sources including cigarettes, BBQ’s, fires, heaters etc, near the inflatable/equipment.",
  },
  {
    info: "12. Do NOT move the inflatable from the position it is erected once the company representative has left the premises.",
  },
  {
    info: "13. The inflatable/equipment must not be operated/used in rain or windy conditions",
  },
  {
    info: "14. Keep children clear of all electrical connections, fan unit and extension leads. In the event of petrol fans being used, please ensure that a safety barrier is erected at all times around the fan.",
  },
  {
    info: "15. If petrol fan is used, when re-fuelling the fan, remove all persons from the equipment, deflate and refuel with utmost care and attention.",
  },
  {
    info: "16. It is the customers’ responsibility to ensure the blower unit is not obstructed with any material or objects that covers the airflow inlet.",
  },
  {
    info: "17. Check periodically that the castle is securely tied to the fan with the rope/fastening provided, and the stakes or anchor points are still securing the castle to the ground. If at all in doubt – do not use the inflatable and call the company.",
  },
  {
    info: "18. Ensure safety mats are in the correct position at the entrance and exit points of the inflatable at all times.",
  },
  {
    info: "19. The inflatable will be supplied to the hirer in a clean condition and it is the hirers’ responsibility to have the inflatable in the same condition at time of collection. Failure to do so will result in the company charging the hirer at £30 per hour to clean the inflatable.",
  },
  {
    info: "20. It is the customers’ responsibility to ensure that an adequate and safe 240V AC mains supply is available at time of delivery and throughout the hire period.",
  },
  {
    info: "21. The hirer agrees to pay the full cost of repair, including carriage to and from the manufacturer, for any damage caused to the inflatable/equipment, whether malicious or accidental, whether by human, animal or other, other than wear and tear.",
  },
];
export const deliveryPolicyData = [
  {
    info: "The cost of delivering to a particular area will be revealed when you choose this area. We may be able to deliver outside the areas available on our website. If you are outside of the areas shown on our website, please contact us to see if we can help you out.",
  },
  {
    info: "If we are unable to provide your delivery due to adverse weather, vehicle failure, illness or any other factor, we will inform you of this at the earliest possible opportunity and provide a full refund. Delivery times can be arranged during the booking process.",
  },
  {
    info: "Please ensure that there is adequate space for our products, that the location our products will be sited is accessible, and that you have cleared the area of mess and debris. We will be unable to provide a refund if we cannot deliver your product due to a lack of space or accessibility or due to an inappropriate location.",
  },
];
export const newsData = [
  {
    title: "🎉 Giant Disco Dome Bouncy Castle – vibrant 2024 Edition!",
    info: "Step into the future of bouncing fun with our latest version of the Giant Disco Dome Bouncy Castle! Immerse your guests in a world of rhythmic joy, combining the thrill of bouncing with the excitement of a disco dance floor. Now available in vibrant colors, this 2024 edition promises an unforgettable multi-sensory experience for both adults and children.",
  },
  {
    title: "🎉 Disco bouncy Castle - NEW 2024 Edition!",
    info: "Introducing our NEW Disco Bouncy Castle! Immerse your event in vibrant joy, combining bouncing fun with a lively disco atmosphere",
  },
  {
    title: "🦕 3D Dinosaur Bouncy Castle with Slide – 2024 Edition!",
    info: "Enhance your Jurassic journey with our updated Dinosaur Soft Play – a perfect companion for the 2024 celebrations! Immerse the little ones in a world of prehistoric play, creating an unforgettable experience that fills the hall or venue with laughter and joy.",
  },
  {
    title: "👑 Pride in Service:",
    info: "At Fun Factor Leeds, our commitment to delivering exceptional service remains unwavering. From seamless setup to perfectly synchronized disco lights, we take pride in exceeding your expectations.",
  },
  {
    title: "🎉 Giant Disco Dome Bouncy Castle – vibrant 2024 Edition!",
    info: "Step into the future of bouncing fun with our latest version of the Giant Disco Dome Bouncy Castle! Immerse your guests in a world of rhythmic joy, combining the thrill of bouncing with the excitement of a disco dance floor. Now available in vibrant colors, this 2024 edition promises an unforgettable multi-sensory experience for both adults and children.",
  },
  {
    title: "🌟 Cleanliness Matters:",
    info: "Safety and satisfaction are our top priorities.",
  },
  {
    title: "📞 Contact Us:",
    info: "Ready to make your 2024 celebration extraordinary? Call us now at (07531) 522289 to discuss your event and secure the latest arrivals. Don't miss out on the new thrills – reserve your date today!",
  },
];
export const indoorData = [
  {
    info: "  We can package together almost any combination of our soft play sets &bouncy castles for your indoor hires.",
  },
  {
    info: "A few examples below of packages we can provide to your home or venue in Leeds, Wakefield, Castleford, Pontefract, Barnsley and Huddersfield.",
  },
  {
    info: "  We can cater for all your needs whether you're having a private party or corporate event. Choose from our large variety of inflatables including.....",
  },
];
export const indoorLinking = [
  {
    url: "  BOUNCY CASTLES ",
  },
  {
    url: " ADULT CASTLES",
  },
  {
    url: " BOUNCE & SLIDE COMBOS",
  },
  {
    url: " DISCO DOMES",
  },
  {
    url: " INFLATABLE GAMES",
  },
  {
    ur: "MEGA SLIDES & ASSALT COURSES",
  },
  {
    url: " SOFT PLAY & BALL POOLS ",
  },
  {
    url: "  PARTY EXTRAS",
  },
];
export const chrismisList = [
  {
    li: "Click DETAILS & BOOKINGS for information of sizes and further details.",
  },
  {
    li: "CHECK AVAILABILITY straight away Online 24/7",
  },
  {
    li: "BOOK ONLINE once you have found the one you want",
  },
];
export const chrismisList2 = [
  {
    li: "FREE delivery to most LS & WF postcodes",
  },
  {
    li: "FREE set up and collection",
  },
  {
    li: "We hold £5million Public Liability Insurance",
  },
  {
    li: "Email confirmation will be sent to confirm your booking",
  },
  {
    li: "100% Reliable",
  },
  {
    li: "We hire to Leeds Morley Pudsey Rothwell Wakefield Castleford Pontefract Barnsley and Huddersfield as standard. If you are outside these areas please call the office on 07531522289 as occassionally we may be able to deliver out of area at quieter times.",
  },
];
export const bookingFormData = [
  {
    label: "Name",
    name: "name",
    type: "text",
    placeholder: "Enter your name",
    rules: {
      required: "Name is required",
      minLength: {
        value: 3,
        message: "Name must be at least 3 characters long",
      },
    },
  },
  {
    label: "Email",
    name: "email",
    type: "email",
    placeholder: "Enter your email",
    rules: {
      required: "Email is required",
      pattern: {
        value: /^\S+@\S+\.\S+£/,
        message: "Invalid email address",
      },
    },
  },
  {
    label: "Phone",
    name: "phone",
    type: "tel",
    placeholder: "Enter your phone number",
    rules: {
      required: "Phone number is required",
      pattern: {
        value: /^\d{10}£/,
        message: "Phone number must be 10 digits",
      },
    },
  },
  {
    label: "Address",
    name: "address",
    type: "text",
    placeholder: "Enter your address",
    rules: {
      required: "Address is required",
    },
  },

  {
    label: "Item Name",
    name: "itemDetail.name",
    type: "text",
    placeholder: "Enter item name",
    rules: {
      required: "Item name is required",
    },
  },
  {
    label: "Item Price",
    name: "itemDetail.price",
    type: "number",
    placeholder: "Enter item price",
    rules: {
      required: "Item price is required",
    },
  },
];

export const contactFormData = [
  {
    label: "Your Name",
    type: "text",
    name: "name",
    placeHolder: "Your Name",
    rules: { required: "Name is required" },
  },
  {
    label: "Your Email Address",
    type: "text",
    name: "email",
    placeHolder: "Your Email Address",
    rules: {
      required: "Email is required",
      pattern: {
        // value: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}£/,
        message: "Invalid email address",
      },
    },
  },
  {
    label: "Your Phone Number",
    type: "text",
    name: "phone",
    placeHolder: "Your Phone Number",
    rules: { required: "Phone number is required" },
  },
  {
    label: "Your Location",
    type: "text",
    name: "location",
    placeHolder: "Your Location",
    rules: { required: "Location is required" },
  },
  {
    label: "Start Date",
    type: "date",
    name: "startDate",
    placeHolder: "Start Date",
    rules: { required: "Start date is required" },
  },
  {
    label: "End Date",
    type: "date",
    name: "endDate",
    placeHolder: "End Date",
    rules: { required: "End date is required" },
  },
  {
    label: "Address",
    type: "textarea",
    name: "address",
    placeHolder: "Your address",
    rules: { required: "Address is required" },
  },
  {
    name: "postalCode",
    label: "Postal Code",
    type: "text",
    placeHolder: "Enter your postal code",
    rules: {
      required: "Postal code is required",
      pattern: {
        value: /^[A-Za-z0-9\s-]+$/,
        message: "Invalid postal code format"
      }
    }
  }
];
